<script setup lang="ts">
import SidebarNavigationComponent from '../components/SidebarNavigationComponent.vue'
</script>

<template>
  <SidebarNavigationComponent></SidebarNavigationComponent>
  <div class="bg-white">
    <div class="flex items-center justify-center min-h-screen">
      <div class="flex items-center justify-center bg-white min-h-screen shadow-lg">
        <div class="max-w-3xl p-6 bg-white rounded flex flex-col gap-10">
          <p>
            This website serves as a dynamic platform, designed to enhance the management and
            annotation of datasets in data science. It provides an interactive web environment for
            users to efficiently add, annotate, and send datasets on-demand, bolstering the
            evaluation process of AI models.
          </p>
          <p>
            The platform offers a versatile user interface and an advanced database model, which
            help users effectively interact with data and understand its representation.
          </p>
          <p>
            An efficient data model, created specifically for annotated data, lies at the core of
            our website, streamlining the storage, management, and annotation of complex datasets.
            Explore this platform and unlock the potential of efficient data science.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped></style>
