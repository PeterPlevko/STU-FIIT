<script setup lang="ts">
import SidebarNavigationComponent from '../components/SidebarNavigationComponent.vue'
import { ref, onMounted } from 'vue'
import Papa from 'papaparse'
import { getFirestore, collection, doc, getDoc, updateDoc } from 'firebase/firestore'
import { useRoute } from 'vue-router'
import axios from 'axios'
import { notify } from '@kyvg/vue3-notification'
import SelectedDatasetCardComponent from '../components/SelectedDatasetCardComponent.vue'
import StickyHeaderComponent from '../components/StickyHeaderComponent.vue'
import DatasetInformationComponent from '../components/DatasetInformationComponent.vue'
import TableComponent from '../components/TableComponent.vue'
import { getAuth } from 'firebase/auth'
import { getStorage, ref as storageRef, getDownloadURL } from 'firebase/storage'
import ProgressSpinner from 'primevue/progressspinner'

const useApi = import.meta.env.VITE_USE_API === 'true'

const apiUrlAnnotation = useApi
  ? import.meta.env.VITE_API_URL
  : import.meta.env.VITE_ANNOTATION_SERVICE_URL

const apiUrlDataset = useApi
  ? import.meta.env.VITE_API_URL
  : import.meta.env.VITE_DATASET_SERVICE_URL

const apiUrlColumn = useApi ? import.meta.env.VITE_API_URL : import.meta.env.VITE_COLUMN_SERVICE_URL

interface ColumnForAnnotation {
  field: string
  header: string
}

interface GetAnotationsResponse {
  createdAt: string
  shortcut: string
  firebaseUserUID: string
  name: string
  description: string
  id: string
  relatedTo: GetAnotationsResponse[]
}

const isLoading = ref(true)
const getAnnotationsResponse = ref<GetAnotationsResponse[] | null>(null)
const columns = ref<ColumnForAnnotation[]>([])
const route = useRoute()
const id = ref<any>(null)
const datasetInformation = ref<typeof DatasetInformationComponent>()
const dataset = ref<any>(null)
const auth = getAuth()
const refreshPageKey = ref(0)

const annotationsSuggestions = ref(null)

interface ColumnDescriptionsResponse {
  columnDescription: string
  columnName: string
}
const columnDescriptionsResponse = ref<ColumnDescriptionsResponse[] | null>(null)

export interface GetColumnsAnnotationsResponse {
  column: ColumnDescriptionsResponse
  annotations: Annotations[]
}

interface Annotations {
  createdAt: string
  shortcut: string
  firebaseUserUID: string
  name: string
  description: string
  id: string
}

const getColumnsAnnotationsResponse = ref<GetColumnsAnnotationsResponse[] | null>(null)

onMounted(async () => {
  const firebaseToken = await (await auth?.currentUser?.getIdTokenResult())?.token

  const db = getFirestore()
  const datasetsCollection = collection(db, 'datasets')
  // table part
  const param = route.params.id
  id.value = param
  const docRef = await getDoc(doc(datasetsCollection, id.value))
  dataset.value = docRef.data()
  if (dataset.value) {
    dataset.value.id = id.value

    try {
      const storage = getStorage()
      const fileRef = storageRef(storage, dataset.value.csvFileUrl)
      const url = await getDownloadURL(fileRef)
      const blob = await fetch(url).then((response) => response.blob())

      const csvData = await blob.text()
      const result = Papa.parse(csvData, {
        header: true,
        dynamicTyping: true
      })
      dataset.value.csvData = result.data
    } catch (error) {
      // Handle any errors
      console.error('Error fetching or parsing data:', error)
    }
    const columnKeys = Object.keys(dataset.value.csvData[0])
    columns.value = columnKeys.map((key) => ({
      field: key,
      header: key
    }))
  }

  // annotations part
  const response = await axios.get(`${apiUrlAnnotation}/annotation/getAnnotations`, {
    headers: {
      Authorization: `${firebaseToken}`
    }
  })

  getAnnotationsResponse.value = response.data

  const responseGetColumnDescriptions = await axios.get(
    `${apiUrlColumn}/column/getColumnsDescriptions`,
    {
      params: {
        datasetId: dataset.value.id
      },
      headers: {
        Authorization: `${firebaseToken}`
      }
    }
  )

  columnDescriptionsResponse.value = responseGetColumnDescriptions.data

  const responseGetColumnAnnotations = await axios.get(
    `${apiUrlAnnotation}/annotation/getColumnsAnnotations`,
    {
      params: {
        datasetId: dataset.value.id
      },
      headers: {
        Authorization: `${firebaseToken}`
      }
    }
  )

  getColumnsAnnotationsResponse.value = responseGetColumnAnnotations.data

  // here I get the annotations suggestions
  const columnsForAnnotationsSuggestionsArray = columns.value.map((item) => item.field)

  const dataToSend = {
    columnsForAnnotationsSuggestionsArray: columnsForAnnotationsSuggestionsArray,
    id: dataset.value.id
  }

  const getAnnotationsSuggestionsResponse = await axios.post(
    `${apiUrlAnnotation}/annotation/getAnnotationsSuggestions`,
    dataToSend,
    {
      headers: {
        Authorization: `${firebaseToken}`
      }
    }
  )
  annotationsSuggestions.value = getAnnotationsSuggestionsResponse.data
})

// annotate submit
let columnData: any[] = []
const itemRefs = ref<(typeof SelectedDatasetCardComponent)[]>([])

const annotateColumn = async () => {
  const firebaseToken = await (await auth?.currentUser?.getIdTokenResult())?.token

  const dataFromChildComponent = await datasetInformation.value?.requestData()

  const dataThing = {
    datasetDescription: dataFromChildComponent.datasetDescription,
    id: dataset.value.id
  }

  const renameDataset = {
    datasetName: dataFromChildComponent.datasetName,
    firebaseDatasetID: dataset.value.id
  }

  // update dataset name
  const db = getFirestore()
  const datasetsCollection = collection(db, 'datasets')

  // Retrieve the existing document
  const datasetDocRef = doc(datasetsCollection, dataset.value.id)
  const datasetDoc = await getDoc(datasetDocRef)

  // Check if the document exists
  if (datasetDoc.exists()) {
    // Update the name property with the value from dataFromChildComponent.datasetDescription
    const updatedDataset = {
      ...datasetDoc.data(),
      datasetName: dataFromChildComponent.datasetName
    }

    // Update the document in the Firestore collection
    await updateDoc(datasetDocRef, updatedDataset)
  } else {
    console.error('Dataset not found')
    // Handle the case when the dataset document does not exist
  }
  // update dataset name

  await axios
    .post(`${apiUrlDataset}/dataset/renameDataset`, renameDataset, {
      headers: {
        Authorization: `${firebaseToken}`
      }
    })
    .then((response) => {
      if (response) {
        notify({
          title: 'Dataset name',
          text: 'Dataset name was updated successfully',
          type: 'success'
        })
      }
    })
    .catch((error) => {
      console.error('Request failed:', error)
      if (error.response && error.response.status === 403) {
        notify({
          title: 'Log in',
          text: 'You need to be logged in to update dataset name',
          type: 'error'
        })
      }
    })

  await axios
    .post(`${apiUrlDataset}/dataset/updateDatasetDescription`, dataThing, {
      headers: {
        Authorization: `${firebaseToken}`
      }
    })
    .then((response) => {
      if (response) {
        notify({
          title: 'Description',
          text: 'Description was updated successfully',
          type: 'success'
        })
      }
    })
    .catch((error) => {
      console.error('Request failed:', error)
      if (error.response && error.response.status === 403) {
        notify({
          title: 'Log in',
          text: 'You need to be logged in to update dataset description',
          type: 'error'
        })
      }
    })

  columnData = []
  // Access child components using refs
  if (Array.isArray(itemRefs.value)) {
    // Loop through child components and request data
    for (const child of itemRefs.value) {
      const data = await child.requestData()

      // Add the data to the array or handle it as needed
      columnData.push(data)
    }
  }

  const columnDataWithoutColumnDescription = columnData.map((item) => {
    return {
      columnName: item.columnName,
      selectedAnnotationId: item.selectedAnnotationId
    }
  })

  const data = {
    firebaseDatasetID: dataset.value.id,
    columns: columnDataWithoutColumnDescription
  }

  const columnDataWithoutAnnotations = columnData.map((item) => {
    return {
      columnName: item.columnName,
      columnDescription: item.columnDescription
    }
  })

  const data1 = {
    firebaseDatasetID: dataset.value.id,
    columns: columnDataWithoutAnnotations
  }

  await axios
    .post(`${apiUrlColumn}/column/updateOrCreate`, data1, {
      headers: {
        Authorization: `${firebaseToken}`
      }
    })
    .then(async (response) => {
      if (response.data) {
        // refreshni columns
        const responseGetColumnDescriptions = await axios.get(
          `${apiUrlColumn}/column/getColumnsDescriptions`,
          {
            params: {
              datasetId: dataset.value.id
            },
            headers: {
              Authorization: `${firebaseToken}`
            }
          }
        )
        if (responseGetColumnDescriptions.data.length > 0) {
          columnDescriptionsResponse.value = []
          columnDescriptionsResponse.value = responseGetColumnDescriptions.data
          refreshPageKey.value++
        }
        notify({
          title: 'Column updated',
          text: 'Column updated successfully.',
          type: 'success'
        })
      } else {
        notify({
          title: 'Column was not updated',
          text: 'Column was not updated successfully',
          type: 'error'
        })
      }
    })
    .catch((error) => {
      console.error('Request failed:', error)
      if (error.response && error.response.status === 403) {
        notify({
          title: 'Log in',
          text: 'You need to be logged in to update column description',
          type: 'error'
        })
      }
    })

  await axios
    .post(`${apiUrlAnnotation}/annotation/annotateColumn`, data, {
      headers: {
        Authorization: `${firebaseToken}`
      }
    })
    .then(async (response) => {
      if (response.data) {
        const responseGetColumnAnnotations = await axios.get(
          `${apiUrlAnnotation}/annotation/getColumnsAnnotations`,
          {
            params: {
              datasetId: dataset.value.id
            },
            headers: {
              Authorization: `${firebaseToken}`
            }
          }
        )

        getColumnsAnnotationsResponse.value = []
        getColumnsAnnotationsResponse.value = responseGetColumnAnnotations.data
        refreshPageKey.value++

        notify({
          title: 'Column annotated',
          text: 'Column annotated successfully.',
          type: 'success'
        })
      } else {
        notify({
          title: 'Column was not annotated',
          text: 'Column was not annotated',
          type: 'error'
        })
      }
    })
    .catch((error) => {
      console.error('Request failed:', error)
      if (error.response && error.response.status === 403) {
        notify({
          title: 'Log in',
          text: 'You need to be logged in to annotate columns',
          type: 'error'
        })
      }
    })
}

const refetchData = async () => {
  const firebaseToken = await (await auth?.currentUser?.getIdTokenResult())?.token

  // annotations part
  const response = await axios.get(`${apiUrlAnnotation}/annotation/getAnnotations`, {
    headers: {
      Authorization: `${firebaseToken}`
    }
  })

  getAnnotationsResponse.value = []
  getAnnotationsResponse.value = response.data
  refreshPageKey.value++

  // annotated columns annotations

  const responseGetColumnAnnotations = await axios.get(
    `${apiUrlAnnotation}/annotation/getColumnsAnnotations`,
    {
      params: {
        datasetId: dataset.value.id
      },
      headers: {
        Authorization: `${firebaseToken}`
      }
    }
  )

  getColumnsAnnotationsResponse.value = []
  getColumnsAnnotationsResponse.value = responseGetColumnAnnotations.data
  refreshPageKey.value++
}

const handleTableLoaded = async () => {
  isLoading.value = false
}
</script>

<template>
  <div v-if="isLoading" class="fixed inset-0 flex items-center justify-center z-50">
    <div class="bg-white p-8 rounded-xl shadow-lg">
      <div class="flex mb-4 items-center justify-center">
        <ProgressSpinner />
      </div>
      <p class="mt-2 text-center">Processing CSV dataset. This may take a while...</p>
    </div>
  </div>

  <SidebarNavigationComponent></SidebarNavigationComponent>

  <StickyHeaderComponent
    v-if="getAnnotationsResponse"
    @dialogClosed="refetchData()"
    @saveChanges="annotateColumn()"
    :getAnnotationsResponse="getAnnotationsResponse"
  ></StickyHeaderComponent>

  <DatasetInformationComponent
    ref="datasetInformation"
    v-if="dataset"
    :dataset="dataset"
  ></DatasetInformationComponent>

  <TableComponent
    v-if="id && dataset && dataset.csvData"
    :datasetCSVData="dataset.csvData"
    :idProps="id"
    @vue:updated="handleTableLoaded"
  ></TableComponent>

  <div class="flex justify-center items-center">
    <div class="m-10 bg-white p-5 rounded-lg max-w-5xl">
      <h1>Annotation part</h1>
    </div>
  </div>

  <div :key="refreshPageKey">
    <div
      v-if="
        getAnnotationsResponse &&
        columnDescriptionsResponse &&
        getColumnsAnnotationsResponse &&
        annotationsSuggestions
      "
    >
      <SelectedDatasetCardComponent
        v-for="(column, index) in columns"
        ref="itemRefs"
        :key="index"
        :columnName="column.field"
        :datasetId="dataset.id"
        :getAnnotationsResponse="getAnnotationsResponse"
        :columnDescriptionsResponse="columnDescriptionsResponse"
        :getColumnsAnnotationsResponse="getColumnsAnnotationsResponse"
        :annotationsSuggestions="annotationsSuggestions"
        :index="index"
      />
    </div>
  </div>
</template>

<style scoped>
html {
  font-size: 14px;
}

body {
  font-family: var(--font-family);
  font-weight: normal;
  background: var(--surface-ground);
  color: var(--text-color);
  padding: 1rem;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.card {
  background: var(--surface-card);
  padding: 2rem;
  border-radius: 10px;
  margin-bottom: 1rem;
}

p {
  line-height: 1.75;
}
</style>

<style>
.selectDatasetTable .p-datatable .p-datatable-footer {
  background-color: white;
  font-weight: 400;
}
</style>
