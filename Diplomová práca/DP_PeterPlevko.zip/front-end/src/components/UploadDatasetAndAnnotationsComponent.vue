<script setup lang="ts">
import Button from 'primevue/button'
import { ref } from 'vue'
import axios from 'axios'
const useApi = import.meta.env.VITE_USE_API === 'true'
const apiUrl = useApi ? import.meta.env.VITE_API_URL : import.meta.env.VITE_ANNOTATION_SERVICE_URL
import { getAuth } from 'firebase/auth'
import { notify } from '@kyvg/vue3-notification'
const emit = defineEmits(['close-dialog'])

const csvFile = ref<File | null>(null)
const jsonFile = ref<File | null>(null)

const upload = async () => {
  if (csvFile.value === null) {
    notify({
      title: 'Error',
      text: 'Please upload CSV file',
      type: 'error'
    })
    return
  }
  if (jsonFile.value === null) {
    notify({
      title: 'Error',
      text: 'Please upload JSON file',
      type: 'error'
    })
    return
  }
  if (csvFile.value && jsonFile.value) {
    const formData = new FormData()
    formData.append('csvFile', csvFile.value)
    formData.append('jsonFile', jsonFile.value)

    // Clear file variables after upload if needed
    csvFile.value = null
    jsonFile.value = null
    const auth = getAuth()
    const firebaseToken = await (await auth?.currentUser?.getIdTokenResult())?.token

    axios
      .post(`${apiUrl}/annotation/postImport`, formData, {
        headers: {
          Authorization: `${firebaseToken}`
        }
      })
      .then((response) => {
        if (response.data) {
          notify({
            title: 'Upload successful',
            text: 'CSV and JSON files uploaded successfully',
            type: 'success'
          })
          emit('close-dialog')
        }
      })
      .catch((error) => {
        console.error('Request failed:', error)
        if (error.response && error.response.status === 403) {
          notify({
            title: 'Log in',
            text: 'You need to be logged in to create a dataset',
            type: 'error'
          })
        }
      })
  }
}

const onUploadCSV = (e: any) => {
  if (e.target.files[0]) {
    if (checkFileExtension(e.target.files[0].name, '.csv')) {
      csvFile.value = e.target.files[0]
    } else {
      notify({
        title: 'Error',
        text: 'Please upload a file with a .csv extension',
        type: 'error'
      })
      resetInput(e.target)
    }
  }
}

const onUploadJSON = (e: any) => {
  if (e.target.files[0]) {
    if (checkFileExtension(e.target.files[0].name, '.json')) {
      jsonFile.value = e.target.files[0]
    } else {
      notify({
        title: 'Error',
        text: 'Please upload a file with a .json extension',
        type: 'error'
      })
      resetInput(e.target)
    }
  }
}

const resetInput = (input: HTMLInputElement) => {
  // Clear the input value
  input.value = ''
}

const checkFileExtension = (fileName: string, extension: string) => {
  return fileName.toLowerCase().endsWith(extension.toLowerCase())
}
</script>

<template>
  <div class="p-4">
    <div class="display flex mb-8">
      <div class="mr-4">
        <label for="formFile" class="mb-2 inline-block text-neutral-500 dark:text-neutral-400"
          >Choose CSV file</label
        >
        <input
          class="relative m-0 block w-full min-w-0 flex-auto cursor-pointer rounded border border-solid border-secondary-500 bg-transparent bg-clip-padding px-3 py-[0.32rem] text-base font-normal text-surface transition duration-300 ease-in-out file:-mx-3 file:-my-[0.32rem] file:me-3 file:cursor-pointer file:overflow-hidden file:rounded-none file:border-0 file:border-e file:border-solid file:border-inherit file:bg-transparent file:px-3 file:py-[0.32rem] file:text-surface focus:border-primary focus:text-gray-700 focus:shadow-inset focus:outline-none dark:border-white/70 dark:text-white file:dark:text-white"
          type="file"
          id="formFile"
          :accept="'.csv'"
          @change="onUploadCSV"
        />
      </div>

      <div class="">
        <label for="formFile" class="mb-2 inline-block text-neutral-500 dark:text-neutral-400"
          >Choose JSON file</label
        >
        <input
          class="relative m-0 block w-full min-w-0 flex-auto cursor-pointer rounded border border-solid border-secondary-500 bg-transparent bg-clip-padding px-3 py-[0.32rem] text-base font-normal text-surface transition duration-300 ease-in-out file:-mx-3 file:-my-[0.32rem] file:me-3 file:cursor-pointer file:overflow-hidden file:rounded-none file:border-0 file:border-e file:border-solid file:border-inherit file:bg-transparent file:px-3 file:py-[0.32rem] file:text-surface focus:border-primary focus:text-gray-700 focus:shadow-inset focus:outline-none dark:border-white/70 dark:text-white file:dark:text-white"
          type="file"
          id="formFile"
          :accept="'.json'"
          @change="onUploadJSON"
        />
      </div>
    </div>
    <div class="display flex justify-center">
      <Button label="Upload dataset and its annotations" icon="" @click="upload()"></Button>
    </div>
  </div>
</template>

<style scoped></style>
