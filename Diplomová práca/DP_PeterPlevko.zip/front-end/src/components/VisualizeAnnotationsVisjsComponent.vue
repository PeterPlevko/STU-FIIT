<script setup lang="ts">
import * as vis from 'vis-network/standalone/umd/vis-network.min.js'
import type { Options } from 'vis-network'

import { onMounted } from 'vue'

interface SelectedAnnotationInformation {
  createdAt: string
  shortcut: string
  firebaseUserUID: string
  name: string
  description: string
  id: string
}

const props = defineProps({
  index: Number,
  selectedAnnotations: {
    type: Array as () => SelectedAnnotationInformation[],
    default: () => []
  },
  allAnnotations: {
    type: Array as any,
    default: () => []
  }
})

onMounted(async () => {
  // create options
  var options: Options = {
    nodes: {
      shape: 'circle',
      size: 100,
      font: {
        color: 'black',
        strokeWidth: 7,
        strokeColor: 'white',
        size: 10
      },
      color: '#3498db'
    },
    edges: {
      selectionWidth: 2,
      length: 200,
      width: 1,
      arrows: {
        to: { enabled: true }
      },
      label: 'RELATED_TO',
      color: 'green',
      font: {
        background: 'none',
        strokeWidth: 0,
        size: 10,
        color: 'Black'
      }
    },
    physics: {
      hierarchicalRepulsion: { avoidOverlap: 1 },
      solver: 'repulsion',
      repulsion: {
        nodeDistance: 100
      }
    }
  }

  // create container
  const container = document.getElementById(`viz${props.index}`)

  // add filtering logic
  function filterAnnotations(
    selectedAnnotations: SelectedAnnotationInformation[],
    allAnnotations: any[]
  ) {
    const reachableAnnotations = new Set()

    function traverseAnnotations(annotation: { name: any; id: unknown; relatedTo: any }) {
      reachableAnnotations.add(annotation.id)
      for (const relatedAnnotation of annotation.relatedTo) {
        const relatedAnnotationObject = allAnnotations.find((a) => a.id === relatedAnnotation.id)
        if (relatedAnnotationObject && !reachableAnnotations.has(relatedAnnotationObject.id)) {
          traverseAnnotations(relatedAnnotationObject)
        }
      }
    }

    for (const annotation of allAnnotations) {
      for (const selectedAnnotation of selectedAnnotations) {
        if (annotation.id === selectedAnnotation.id) {
          traverseAnnotations(annotation)
          break
        }
        if (
          annotation.relatedTo.find(
            (relatedAnnotation: { id: string }) => relatedAnnotation.id === selectedAnnotation.id
          )
        ) {
          traverseAnnotations(annotation)
          break
        }
      }
    }

    return allAnnotations.filter((annotation) => reachableAnnotations.has(annotation.id))
  }

  function createNodesArray(annotations: any[], selectedAnnotations: any[]) {
    const nodes = []

    for (const annotation of annotations) {
      const element = document.createElement('div')
      const content = `
      <strong>id:</strong> ${annotation.id}<br>
      <strong>name:</strong> ${annotation.name}<br>
      <strong>shortcut:</strong> ${annotation.shortcut}<br>
      <strong>description:</strong> ${annotation.description}<br>
      <strong>createdAt:</strong> ${annotation.createdAt}<br>
      <strong>firebaseUserUID:</strong> ${annotation.firebaseUserUID}<br>
    `
      element.innerHTML = content

      const node = {
        id: annotation.id,
        label: annotation.name,
        title: element,
        color: '#3498db'
      }

      // Color selected annotations
      if (selectedAnnotations.some((selected) => selected.id === annotation.id)) {
        node.color = '#e74c3c'
      }

      nodes.push(node)
    }

    return nodes
  }

  interface AddedEdges {
    [key: string]: boolean
  }
  function createEdgesArray(annotations: any[]) {
    const edges: any[] = []
    const addedEdges: AddedEdges = {}

    annotations.forEach((annotation) => {
      if (annotation.relatedTo && annotation.relatedTo.length > 0) {
        const fromId = annotation.id
        const toId = annotation.relatedTo[0].id

        // Check if the edge is already added
        const edgeKey = `${fromId}_${toId}`
        if (!addedEdges[edgeKey]) {
          edges.push({ from: fromId, to: toId })
          addedEdges[edgeKey] = true
        }

        // Connect each related annotation to the next one
        for (let i = 0; i < annotation.relatedTo.length - 1; i++) {
          const fromRelated = annotation.relatedTo[i].id
          const toRelated = annotation.relatedTo[i + 1].id
          const relatedEdgeKey = `${fromRelated}_${toRelated}`
          if (!addedEdges[relatedEdgeKey]) {
            edges.push({ from: fromRelated, to: toRelated })
            addedEdges[relatedEdgeKey] = true
          }
        }
      }
    })

    return edges
  }

  const filteredAnnotations = filterAnnotations(props.selectedAnnotations, props.allAnnotations)

  const nodesArray = createNodesArray(filteredAnnotations, props.selectedAnnotations)
  const edgesArray = createEdgesArray(filteredAnnotations)

  var data = {
    nodes: nodesArray,
    edges: edgesArray
  }
  new vis.Network(container!, data, options)
})
</script>

<template>
  <div
    class="mx-auto h-full w-full flex justify-center border border-gray-300"
    :id="`viz${props.index}`"
  ></div>
</template>

<style scoped></style>
