<script setup lang="ts">
import { notify } from '@kyvg/vue3-notification'
import { onMounted, ref } from 'vue'
import Button from 'primevue/button'
import Dialog from 'primevue/dialog'
import InputText from 'primevue/inputtext'
import axios from 'axios'
import { getAuth } from 'firebase/auth'
const auth = getAuth()
const useApi = import.meta.env.VITE_USE_API === 'true'
const apiUrl = useApi ? import.meta.env.VITE_API_URL : import.meta.env.VITE_DATASET_SERVICE_URL

const props = defineProps({
  dataset: Object
})
onMounted(async () => {
  const firebaseToken = await (await auth?.currentUser?.getIdTokenResult())?.token

  const response = await axios.get(`${apiUrl}/dataset/getDatasetDescription/${props.dataset?.id}`, {
    headers: {
      Authorization: `${firebaseToken}`
    }
  })

  datasetDescription.value = response.data
  datasetName.value = props.dataset?.datasetName
})

const datasetName = ref<any>(null)
const datasetDescription = ref<any>(null)
const descriptionPopUpVisible = ref(false)
const datasetChangeNamePopup = ref(false)
const newDatasetName = ref('')
const newDatasetDescription = ref('')

const changeDescription = () => {
  if (newDatasetDescription.value !== '') {
    datasetDescription.value = newDatasetDescription.value
    descriptionPopUpVisible.value = false
    newDatasetDescription.value = ''
  } else {
    notify({
      title: 'Description',
      text: 'Description cannot be empty',
      type: 'error'
    })
  }
}

const requestData = async () => {
  return {
    datasetDescription: datasetDescription.value,
    datasetName: datasetName.value
  }
}

defineExpose({
  requestData
})

const changeDatasetName = () => {
  if (newDatasetName.value !== '') {
    datasetName.value = newDatasetName.value
    datasetChangeNamePopup.value = false
    newDatasetName.value = ''
  } else {
    notify({
      title: 'Name',
      text: 'Name cannot be empty',
      type: 'error'
    })
  }
}
</script>

<template>
  <div class="flex justify-center items-center">
    <div class="mb-10 bg-white p-5 rounded-lg max-w-5xl mt-28">
      <div class="flex flex-col items-center">
        <h1 class="m-2 text-xl font-bold">Dataset name</h1>
        <h1 v-if="datasetName">{{ datasetName }}</h1>
        <h1 v-else>Name not found</h1>
      </div>
      <div class="mt-2 flex flex-col items-center">
        <Button @click="datasetChangeNamePopup = true">Change dataset name</Button>
      </div>
      <div>
        <Dialog v-model:visible="datasetChangeNamePopup" modal header="Change dataset name">
          <div class="flex flex-col items-center">
            <p v-if="datasetName">{{ datasetName }}</p>
            <InputText class="m-2" type="text" v-model="newDatasetName" />
            <Button class="m-2" @click="changeDatasetName">Save dataset name</Button>
          </div>
        </Dialog>
      </div>

      <div class="flex flex-col items-center">
        <h1 class="m-2 text-xl font-bold">Dataset description</h1>
        <h1 v-if="datasetDescription">{{ datasetDescription }}</h1>
        <h1 v-else>Dataset description not found</h1>
      </div>
      <div class="mt-2 flex flex-col items-center">
        <Button @click="descriptionPopUpVisible = true">Change description</Button>
      </div>
      <div>
        <Dialog v-model:visible="descriptionPopUpVisible" modal header="Change dataset description">
          <div class="flex flex-col items-center">
            <p v-if="datasetDescription">{{ datasetDescription }}</p>
            <p v-else>No description yet</p>
            <InputText class="m-2" type="text" v-model="newDatasetDescription" />
            <Button class="m-2" @click="changeDescription">Save description</Button>
          </div>
        </Dialog>
      </div>
    </div>
  </div>
</template>
<style scoped></style>
