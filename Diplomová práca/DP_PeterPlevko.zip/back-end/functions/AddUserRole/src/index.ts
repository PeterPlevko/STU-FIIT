import * as firebase from "firebase-admin";
import * as functions from "firebase-functions";

// login part
const minInstances = 1;
const maxInstances = 2;

firebase.initializeApp({});

export const AddUserRole = functions.region("europe-west3")
  .runWith({minInstances: minInstances, maxInstances: maxInstances})
  .auth.user().onCreate(async (authUser) => {
    const db = firebase.firestore();

    if (authUser.email) {
      const customClaims = {
        user: true,
      };
      try {
        await firebase.auth().setCustomUserClaims(authUser.uid, customClaims);

        return db.collection("roles").doc(authUser.uid).set({
          email: authUser.email,
          role: customClaims,
        });
      } catch (error) {
        console.log(error);
        return null;
      }
    }
    return null;
  });
