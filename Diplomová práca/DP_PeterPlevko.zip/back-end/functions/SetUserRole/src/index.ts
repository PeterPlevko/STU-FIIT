import * as firebase from "firebase-admin";
import * as functions from "firebase-functions";

// change role part
const minInstances = 1;
const maxInstances = 2;

firebase.initializeApp({});

export const SetUserRole = functions.region("europe-west3")
  .runWith({minInstances: minInstances, maxInstances: maxInstances})
  .https.onCall(async (data, context) => {
    const db = firebase.firestore();
    if (!context.auth?.token.admin) return null;

    try {
      await firebase.auth().setCustomUserClaims(data.uid, data.role);

      return db.collection("roles").doc(data.uid).update({
        role: data.role,
      });
    } catch (error) {
      console.log(error);
      return null;
    }
  });
