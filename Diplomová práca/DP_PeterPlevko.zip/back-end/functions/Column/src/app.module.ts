import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { ColumnModule } from './api/column/column.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' }),
    ColumnModule,
  ],
  controllers: [AppController],
  providers: [],
})
export class AppModule {}
