import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { DatasetModule } from './api/dataset/dataset.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' }),
    DatasetModule,
  ],
  controllers: [AppController],
  providers: [],
})
export class AppModule {}
