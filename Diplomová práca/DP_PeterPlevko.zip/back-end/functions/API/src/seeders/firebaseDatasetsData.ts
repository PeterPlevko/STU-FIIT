// Dataset
const firestoreDatasets = [
  {
    id: 'jloUpYvlndz8Of1NQv1M',
    authorName: 'admin@gmail.com',
    authorUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    csvFileUrl: `mkt_synthetic.csv`,
    datasetName: 'mkt_synthetic',
    publishDate: '11/17/2023, 2:03:21 PM',
    size: 'small',
  },
  {
    id: 'm7LxNH7cOHwHZG0yei7I',
    authorName: 'admin@gmail.com',
    authorUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    csvFileUrl: `KAG_conversion_data.csv`,
    datasetName: 'KAG_conversion_data',
    publishDate: '11/19/2023, 8:22:03 PM',
    size: 'small',
  },
  {
    id: 'i11dedyswB5bQ7RVTkD0',
    authorName: 'admin@gmail.com',
    authorUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    csvFileUrl: `Ecommerce Customers.csv`,
    datasetName: 'Ecommerce Customers',
    publishDate: '12/1/2023, 4:59:59 PM',
    size: 'small',
  },
  {
    id: 'uxwlXEiVAE0waBhFC5VS',
    authorName: 'admin@gmail.com',
    authorUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    csvFileUrl: `conversion_data.csv`,
    datasetName: 'conversion_data',
    publishDate: '2/24/2024, 5:34:18 PM',
    size: 'big',
  },
  {
    id: 'utwlXasdEiVAE0waBhFC5VSasdads',
    authorName: 'admin@gmail.com',
    authorUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    csvFileUrl: `customer_conversion_traing_dataset.csv`,
    datasetName: 'customer_conversion_traing_dataset',
    publishDate: '2/24/2024, 5:34:23 PM',
    size: 'big',
  },
];

export default firestoreDatasets;
