// seeder.service.ts
import { Injectable } from '@nestjs/common';
import { FirebaseService } from '../firebase/fire-base.service';
import firestoreDatasets from './firebaseDatasetsData';
import { SeedNeo4j } from './seed-neo4j-service';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import { SeedPostgreSQL } from './seed-postgresql-service';
import { ConfigService } from '@nestjs/config';

const BASE_PATH = path.join(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  './datasets',
  '/',
); // Move two levels up to reach the root
const bucketName = 'diploma-thesis-project-c46d9.appspot.com';

@Injectable()
export class SeederService {
  constructor(
    private readonly firebaseService: FirebaseService,
    private readonly seedNeo4j: SeedNeo4j,
    private readonly seedPostgreSQL: SeedPostgreSQL,
    private readonly configService: ConfigService,
  ) {}

  // seed postgresql
  async seedNeo4jDatabase() {
    const app = this.firebaseService.getAdmin();
    const db = app.firestore();
    const datasetsCollection = db.collection('datasets');
    const storage = app.storage();

    // Create a deep copy of the datasets to avoid modifying the original objects
    const copiedDatasets = JSON.parse(JSON.stringify(firestoreDatasets));

    for (const dataset of copiedDatasets) {
      // Check if the dataset with the same ID exists
      const datasetId = dataset.id;
      const existingDataset = await datasetsCollection.doc(datasetId).get();

      if (!existingDataset.exists) {
        const downloadUrl = await this.uploadFile(dataset, storage);
        // Dataset doesn't exist, so add it
        dataset.csvFileUrl = downloadUrl;
        await datasetsCollection.doc(datasetId).set(dataset);
        console.log('Dataset added to Firestore.');
      }
    }

    // Seed Neo4j
    this.seedNeo4j.createAnnotation();
    console.log('database seeded');
  }

  async uploadFile(dataset: any, storage: any) {
    const developmentType = this.configService.get<string>('DEVELOPMENT_TYPE');
    let filePath = null;
    let fileName = null;
    if (developmentType === 'dev') {
      filePath = path.join(BASE_PATH, dataset.csvFileUrl);
      fileName = path.basename(filePath);
    } else {
      filePath = path.join(__dirname, 'datasets', dataset.csvFileUrl);
      fileName = path.basename(filePath);
    }

    console.log('fileName', fileName);
    console.log('filePath', filePath);

    const uniqueFileName = `${uuidv4()}_${fileName}`;
    const storageFilePath = `csvFiles/${uniqueFileName}`;

    try {
      await storage.bucket(bucketName).upload(filePath, {
        destination: storageFilePath,
      });
      console.log('File uploaded successfully.');

      // Generate a signed URL for the uploaded file
      const [url] = await storage
        .bucket(bucketName)
        .file(storageFilePath)
        .getSignedUrl({
          action: 'read',
          expires: Date.now() + 365 * 24 * 60 * 60 * 1000, // Link expiration time (1 year)
        });
      return url; // Return the download URL
    } catch (error) {
      console.error('Error uploading file:', error);
    }
  }

  // seed postgresql
  async seedPostgreSQLDatabase() {
    const app = this.firebaseService.getAdmin();
    const db = app.firestore();
    const datasetsCollection = db.collection('datasets');
    const storage = app.storage();

    // Create a deep copy of the datasets to avoid modifying the original objects
    const copiedDatasets = JSON.parse(JSON.stringify(firestoreDatasets));

    for (const dataset of copiedDatasets) {
      // Check if the dataset with the same ID exists
      const datasetId = dataset.id;
      const existingDataset = await datasetsCollection.doc(datasetId).get();

      if (!existingDataset.exists) {
        const downloadUrl = await this.uploadFile(dataset, storage);
        // Dataset doesn't exist, so add it
        dataset.csvFileUrl = downloadUrl;
        await datasetsCollection.doc(datasetId).set(dataset);
        console.log('Dataset added to Firestore.');
      }
    }

    // Seed Neo4j
    this.seedPostgreSQL.createAnnotations();
    console.log('database seeded');
  }

  async testingNeo4j(numberOfAnnotations: number) {
    const app = this.firebaseService.getAdmin();
    const db = app.firestore();
    const datasetsCollection = db.collection('datasets');
    const storage = app.storage();

    // Create a deep copy of the datasets to avoid modifying the original objects
    const dataset = JSON.parse(JSON.stringify(firestoreDatasets[0]));

    // Check if the dataset with the same ID exists
    const datasetId = dataset.id;
    const existingDataset = await datasetsCollection.doc(datasetId).get();

    if (!existingDataset.exists) {
      const downloadUrl = await this.uploadFile(dataset, storage);
      // Dataset doesn't exist, so add it
      dataset.csvFileUrl = downloadUrl;
      await datasetsCollection.doc(datasetId).set(dataset);
      console.log('Dataset added to Firestore.');
    }

    // Seed Neo4j
    this.seedNeo4j.testing(numberOfAnnotations);
    console.log('database seeded');
  }

  async testingPostgreSQL(numberOfAnnotations: number) {
    const app = this.firebaseService.getAdmin();
    const db = app.firestore();
    const datasetsCollection = db.collection('datasets');
    const storage = app.storage();

    // Create a deep copy of the datasets to avoid modifying the original objects
    const dataset = JSON.parse(JSON.stringify(firestoreDatasets[0]));

    // Check if the dataset with the same ID exists
    const datasetId = dataset.id;
    const existingDataset = await datasetsCollection.doc(datasetId).get();

    if (!existingDataset.exists) {
      const downloadUrl = await this.uploadFile(dataset, storage);
      // Dataset doesn't exist, so add it
      dataset.csvFileUrl = downloadUrl;
      await datasetsCollection.doc(datasetId).set(dataset);
      console.log('Dataset added to Firestore.');
    }

    // Seed Neo4j
    this.seedPostgreSQL.testing(numberOfAnnotations);
    console.log('database seeded');
  }
}
