import { Injectable } from '@nestjs/common';
import { node, relation } from 'cypher-query-builder';
import { QueryRepository } from 'src/neo4j/query.repository';
import { v4 as uuidv4 } from 'uuid';

const datasets = [
  {
    datasetName: 'mkt_synthetic',
    datasetDescription: 'mkt_synthetic dataset description',
    firebaseDatasetID: 'jloUpYvlndz8Of1NQv1M',
    firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    columnAnnotationData: [
      // uid column
      {
        columnName: 'uid',
        annotationId: 'dddef883-cf22-4b62-811b-ecfb78b0a159', // Entity Identifier
      },
      {
        columnName: 'uid',
        annotationId: '77b7712d-b08d-4373-ab25-9d57547b6908', // Page View
      },
      // visit_date
      {
        columnName: 'visit_date',
        annotationId: 'a8ec5bbb-91a4-4764-9b3e-85e3048be233', // Created At
      },
      {
        columnName: 'visit_date',
        annotationId: '65165a93-0b8d-4b8a-859a-d00998bf6646', // Updated At
      },
      {
        columnName: 'visit_date',
        annotationId: '9553e757-c6fd-40b8-8c67-d33645a9ed36', // Deleted At
      },
      {
        columnName: 'visit_date',
        annotationId: '30217443-c6db-4f67-9e67-8d0ca94840c4', // Conversion Rate Analysis
      },

      // utm_source
      {
        columnName: 'utm_source',
        annotationId: '96dde0c9-8c4f-41de-bad6-2d52bbcf960f', // UTM Source
      },
      // utm_medium
      {
        columnName: 'utm_medium',
        annotationId: '92cb77f1-9d73-4796-807c-c2a1b988a694', // UTM Medium
      },
      // utm_campaign
      {
        columnName: 'utm_campaign',
        annotationId: '67485b26-4c2e-474a-9667-7b1b344930bf', // UTM Campaign
      },
      // converted
      {
        columnName: 'converted',
        annotationId: '4d230c7e-daf4-4111-b808-c6060536f1e8', // Flag
      },

      {
        columnName: 'converted',
        annotationId: 'bed6d944-88e6-4193-9fc7-1cf111487237', // Conversion
      },

      {
        columnName: 'converted',
        annotationId: '30217443-c6db-4f67-9e67-8d0ca94840c4', // Conversion Rate Analysis
      },

      // CostOfClick
      {
        columnName: 'cost_of_click',
        annotationId: '65ade3c6-9af2-43cd-a732-2ecfe5932f3c', // Cost Per Click
      },
    ],
    annotationData: [
      // uid column
      {
        id: 'dddef883-cf22-4b62-811b-ecfb78b0a159',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'An entity identifier is a unique reference or key that uniquely identifies an entity in a system or dataset.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Entity Identifier',
        shortcut: 'entity_identifier',
      },

      {
        id: '77b7712d-b08d-4373-ab25-9d57547b6908',
        createdAt: new Date('2023-02-07T10:00:00.123Z').toISOString(),
        description:
          'A page view refers to a single instance of a user viewing a web page. It is a metric used to measure website or application traffic and engagement.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Page View',
        shortcut: 'page_view',
      },

      // visit_date
      {
        id: 'a8ec5bbb-91a4-4764-9b3e-85e3048be233',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description: 'The date and time when an entity or record was created.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Created At',
        shortcut: 'created_at',
      },
      {
        id: '65165a93-0b8d-4b8a-859a-d00998bf6646',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'The date and time when an entity or record was last updated.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Updated At',
        shortcut: 'updated_at',
      },
      {
        id: '9553e757-c6fd-40b8-8c67-d33645a9ed36',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'The date and time when an entity or record was soft-deleted or marked as deleted.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Deleted At',
        shortcut: 'deleted_at',
      },
      {
        id: '81ba4f8a-c812-4d4e-a171-a6d8e6e0a0d7',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'A date represents a specific point in time, typically expressed in the format YYYY-MM-DD. Dates are used to track and reference events, schedules, and durations.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Date',
        shortcut: 'date',
      },

      // utm_source
      {
        id: '96dde0c9-8c4f-41de-bad6-2d52bbcf960f',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'Identifies which site sent the traffic (required parameter).',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'UTM Source',
        shortcut: 'utm_source',
      },

      // utm_medium
      {
        id: '92cb77f1-9d73-4796-807c-c2a1b988a694',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'Identifies what type of link was used, such as cost per click or email.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'UTM Medium',
        shortcut: 'utm_medium',
      },

      // utm_campaign
      {
        id: '67485b26-4c2e-474a-9667-7b1b344930bf',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'Identifies a specific product promotion or strategic campaign.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'UTM Campaign',
        shortcut: 'utm_campaign',
      },

      // converted

      {
        id: '4d230c7e-daf4-4111-b808-c6060536f1e8',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'In data representation, a flag is a binary marker used to indicate the presence (true) or absence (false) of a specific condition or state. Flags are commonly employed to signify the completion or non-completion of a particular task or event.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Flag',
        shortcut: 'flag',
      },
      {
        id: '13f2ec8e-7e49-401e-8dd9-e8156a7b21a8',
        createdAt: new Date('2023-04-07T17:45:00.789Z').toISOString(),
        description:
          'Annotates the presence or confirmation of a true condition.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'True Condition',
        shortcut: 'true_condition',
      },

      {
        id: '0e19bf95-d8a0-4de7-b5cf-09b4874a90be',
        createdAt: new Date('2023-04-07T17:45:00.789Z').toISOString(),
        description: 'Annotates the absence or negation of a true condition.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'False Condition',
        shortcut: 'false_condition',
      },

      {
        id: 'bed6d944-88e6-4193-9fc7-1cf111487237',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'A conversion represents the successful completion of a predefined goal or desired action. It is a significant outcome that signifies positive user engagement and aligns with the objectives of a business, website, or marketing campaign.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Conversion',
        shortcut: 'conversion',
      },
      {
        id: 'aecd8bb6-b7ac-42a4-ac24-013c4d24fbd5',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'Key Performance Indicator (KPI) is a measurable value that indicates the effectiveness and success of an organization, business process, or specific activity. KPIs are used to evaluate performance against strategic goals and objectives.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'KPI',
        shortcut: 'kpi',
      },

      {
        id: '30217443-c6db-4f67-9e67-8d0ca94840c4',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'Conversion Rate Analysis involves evaluating the relationship between "Converted" events and timestamps. It aims to calculate conversion rates, providing insights into how effectively campaigns perform and how user interactions vary over different time periods.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Conversion Rate Analysis',
        shortcut: 'conversion_rate_analysis',
      },

      {
        id: '6531c8ed-a185-43f4-96e4-db0aa618c97d',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'User Behavior analysis delves into the actions and interactions of users. It is a crucial component of Conversion Rate Analysis, providing insights into user engagement patterns and conversion triggers.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'User Behavior',
        shortcut: 'user_behavior',
      },
      {
        id: 'eeb88c64-279e-47ba-8c35-fd239e3d275a',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'Performance Metrics encompass a range of key indicators, including user behavior metrics and conversion rates. They provide a comprehensive view of the effectiveness of strategies and user satisfaction.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Performance Metrics',
        shortcut: 'performance_metrics',
      },

      // cost_of_click
      {
        id: '65ade3c6-9af2-43cd-a732-2ecfe5932f3c',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'Cost Per Click (CPC) is a financial metric in marketing. It measures the cost an advertiser pays for each click on their advertisement.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Cost Per Click',
        shortcut: 'cost_per_click',
      },

      {
        id: '95fc967d-7454-4ced-b3e5-b836fb856473',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'A financial metric is a quantifiable measure used to assess the financial health and performance of a business.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Financial Metric',
        shortcut: 'financial_metric',
      },

      {
        id: '0d476f14-001b-49c9-8231-03229a81b8ae',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'A metric is a quantifiable measure used for assessing, comparing, and tracking performance.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Metric',
        shortcut: 'metric',
      },

      {
        id: '3f9012f6-f2ff-48d1-a731-859bbb168e8c',
        createdAt: new Date('2023-10-07T10:00:00.123Z').toISOString(),
        description:
          'Urchin Tracking Module (UTM) parameters used by marketers to track the effectiveness of online marketing campaigns.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'UTM Parameters',
        shortcut: 'utm_parameters',
      },

      {
        id: 'e3b1b710-0d64-496b-964a-0ac6f97317d9',
        createdAt: new Date('2023-10-07T10:00:00.123Z').toISOString(),
        description:
          'Marketing is the process of identifying customers and "creating, communicating, delivering, and exchanging" goods and services for the satisfaction and retention of those customers. It is one of the primary components of business management and commerce.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Marketing',
        shortcut: 'marketing',
      },
    ],
    relatedAnnotations: [
      // visit_date

      {
        sourceId: 'a8ec5bbb-91a4-4764-9b3e-85e3048be233', // Created At
        targetId: '81ba4f8a-c812-4d4e-a171-a6d8e6e0a0d7', // Date
      },
      {
        sourceId: '65165a93-0b8d-4b8a-859a-d00998bf6646', // Updated At
        targetId: '81ba4f8a-c812-4d4e-a171-a6d8e6e0a0d7', // Date
      },
      {
        sourceId: '9553e757-c6fd-40b8-8c67-d33645a9ed36', // Deleted At
        targetId: '81ba4f8a-c812-4d4e-a171-a6d8e6e0a0d7', // Date
      },
      // utm_source
      {
        sourceId: '96dde0c9-8c4f-41de-bad6-2d52bbcf960f', // UTM Source
        targetId: '3f9012f6-f2ff-48d1-a731-859bbb168e8c', // UTM Parameters
      },
      // utm_medium
      {
        sourceId: '92cb77f1-9d73-4796-807c-c2a1b988a694', // UTM Medium
        targetId: '3f9012f6-f2ff-48d1-a731-859bbb168e8c', // UTM Parameters
      },
      // utm_campaign
      {
        sourceId: '67485b26-4c2e-474a-9667-7b1b344930bf', // UTM Campaign
        targetId: '3f9012f6-f2ff-48d1-a731-859bbb168e8c', // UTM Parameters
      },
      // converted
      {
        sourceId: '13f2ec8e-7e49-401e-8dd9-e8156a7b21a8', // True Condition
        targetId: '4d230c7e-daf4-4111-b808-c6060536f1e8', // Flag
      },

      {
        sourceId: '0e19bf95-d8a0-4de7-b5cf-09b4874a90be', // False Condition
        targetId: '4d230c7e-daf4-4111-b808-c6060536f1e8', // Flag
      },

      {
        sourceId: 'bed6d944-88e6-4193-9fc7-1cf111487237', // Conversion
        targetId: 'aecd8bb6-b7ac-42a4-ac24-013c4d24fbd5', // KPI
      },

      {
        sourceId: 'aecd8bb6-b7ac-42a4-ac24-013c4d24fbd5', // KPI
        targetId: 'e3b1b710-0d64-496b-964a-0ac6f97317d9', // Marketing
      },

      {
        sourceId: '30217443-c6db-4f67-9e67-8d0ca94840c4', // Conversion Rate Analysis
        targetId: '6531c8ed-a185-43f4-96e4-db0aa618c97d', // User Behavior
      },

      {
        sourceId: '6531c8ed-a185-43f4-96e4-db0aa618c97d', // User Behavior
        targetId: 'eeb88c64-279e-47ba-8c35-fd239e3d275a', // Performance Metrics
      },

      {
        sourceId: 'eeb88c64-279e-47ba-8c35-fd239e3d275a', // Performance Metrics
        targetId: '0d476f14-001b-49c9-8231-03229a81b8ae', // metric
      },

      // cost_of_click
      {
        sourceId: '65ade3c6-9af2-43cd-a732-2ecfe5932f3c', // Cost Per Click
        targetId: '95fc967d-7454-4ced-b3e5-b836fb856473', // Financial Metric
      },

      {
        sourceId: '95fc967d-7454-4ced-b3e5-b836fb856473', // Financial Metric
        targetId: '0d476f14-001b-49c9-8231-03229a81b8ae', // Metric
      },

      {
        sourceId: '0d476f14-001b-49c9-8231-03229a81b8ae', // Metric
        targetId: 'e3b1b710-0d64-496b-964a-0ac6f97317d9', // Marketing
      },

      // others
      {
        sourceId: '3f9012f6-f2ff-48d1-a731-859bbb168e8c', // UTM Parameters
        targetId: 'e3b1b710-0d64-496b-964a-0ac6f97317d9', // Marketing
      },
    ],
    columnData: [
      {
        columnName: 'uid',
        columnDescription:
          'Unique Identifier: A unique alphanumeric code assigned to each visitor for identification purposes.',
      },
      {
        columnName: 'visit_date',
        columnDescription:
          'Visit Date: The date when the visitor accessed the website or platform.',
      },
      {
        columnName: 'utm_source',
        columnDescription:
          'UTM Source: The specific source that directed the visitor to the website, often used in UTM parameters for tracking marketing efforts (e.g., "facebook", "google").',
      },
      {
        columnName: 'utm_medium',
        columnDescription:
          'UTM Medium: The general category of the marketing medium that brought the visitor to the website (e.g., "email", "cpc").',
      },
      {
        columnName: 'utm_campaign',
        columnDescription:
          'UTM Campaign: The specific marketing campaign or promotion that led to the visit (e.g., "summer_sale", "holiday_promo").',
      },
      {
        columnName: 'converted',
        columnDescription:
          'Conversion Status: Indicates whether the visitor completed a desired action or goal on the website (e.g., true for conversion, false for non-conversion).',
      },
      {
        columnName: 'cost_of_click',
        columnDescription:
          'Cost of Click: The monetary cost incurred for each click associated with the marketing campaign or source that brought the visitor to the website.',
      },
    ],
  },
  {
    datasetName: 'KAG_conversion_data',
    datasetDescription: 'KAG_conversion_data dataset description',
    firebaseDatasetID: 'm7LxNH7cOHwHZG0yei7I',
    firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    columnAnnotationData: [
      // ad_id
      {
        columnName: 'ad_id',
        annotationId: 'eba06d58-54a6-418e-86b8-6319e65eccb5', // Ad Identifier
      },
      // xyz_campaign_id
      {
        columnName: 'xyz_campaign_id',
        annotationId: '473fd8d5-8ab7-45ef-9d36-9be34952dc93', // XYZ Campaign Identifier
      },
      // fb_campaign_id
      {
        columnName: 'fb_campaign_id',
        annotationId: '8df8e411-68d8-4eb7-a338-4b73ba57dd50', // Facebook Campaign Identifier
      },
      // age
      {
        columnName: 'age',
        annotationId: '41900e8d-bbd5-40c5-a0e8-bf89c5a21ad0', // Age Range
      },
      {
        columnName: 'age',
        annotationId: 'd5b0ad4c-9a2b-407f-9b24-e5703e4de9e9', // Years
      },
      // gender
      {
        columnName: 'gender',
        annotationId: '3b0957e5-28bc-494a-92f3-e538e3ec2f56', // Gender
      },
      // interest
      // Impressions
      {
        columnName: 'Impressions',
        annotationId: 'ea0c0ac8-a281-4c2b-951a-936708bc3541', // Impressions
      },
      {
        columnName: 'Impressions',
        annotationId: 'fd702ab0-ebcf-4e04-a915-53e52b371590', // Visibility Metric
      },
      // Clicks
      {
        columnName: 'Clicks',
        annotationId: '49eae644-e9b9-4e09-a0e1-a8fbbc6bb8da', // Click Definition
      },

      // Spent
      {
        columnName: 'Spent',
        annotationId: 'da895aa4-6fba-4d1f-a696-06f6f00581fa', // Expenditure Indicator
      },
      {
        columnName: 'Spent',
        annotationId: 'e16ffefa-cf62-4559-9fb2-2f99a8948700', // Cost-Efficiency
      },
      // Total_Conversion
      {
        columnName: 'Total_Conversion',
        annotationId: 'e16ffefa-cf62-4559-9fb2-2f99a8948700', // Cost-Efficiency
      },
      {
        columnName: 'Total_Conversion',
        annotationId: '632ed456-69b7-4fbf-8c15-298ceefbb59c', // Conversion Rate
      },
      // Approved_Conversion
      {
        columnName: 'Approved_Conversion',
        annotationId: '4ea7abb8-e015-4673-8d6d-68c8f664bd2a', // Conversion Approval Metric
      },
      {
        columnName: 'Approved_Conversion',
        annotationId: 'e16ffefa-cf62-4559-9fb2-2f99a8948700', // Cost-Efficiency
      },
      {
        columnName: 'Approved_Conversion',
        annotationId: '632ed456-69b7-4fbf-8c15-298ceefbb59c', // Conversion Rate
      },
    ],
    annotationData: [
      // ad_id
      {
        id: 'eba06d58-54a6-418e-86b8-6319e65eccb5',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'Ad Identifier: Ad ID is a unique identifier assigned to individual advertisements in the marketing campaign. It facilitates tracking, analysis, and management of ad performance.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Ad Identifier',
        shortcut: 'ad_identifier',
      },
      // xyz_campaign_id
      {
        id: '473fd8d5-8ab7-45ef-9d36-9be34952dc93',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'XYZ Campaign Identifier: XYZ Campaign ID serves as a unique identifier for advertisements associated with the XYZ campaign. It facilitates tracking, analysis, and management of ads within this specific marketing initiative.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'XYZ Campaign Identifier',
        shortcut: 'xyz_campaign_identifier',
      },
      // fb_campaign_id
      {
        id: '8df8e411-68d8-4eb7-a338-4b73ba57dd50',
        createdAt: new Date('2023-03-07T10:00:00.123Z').toISOString(),
        description:
          'Facebook Campaign Identifier: Facebook Campaign ID serves as a unique identifier for advertisements associated with a specific Facebook campaign. It plays a crucial role in tracking, analyzing, and managing ads within the Facebook platform.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Facebook Campaign Identifier',
        shortcut: 'fb_campaign_identifier',
      },
      // age
      {
        id: '41900e8d-bbd5-40c5-a0e8-bf89c5a21ad0',
        createdAt: new Date('2023-04-07T10:00:00.123Z').toISOString(),
        description:
          'An age range is a segment of the population grouped based on a specified span of ages. It allows for tailored marketing strategies within the categorized age group.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Age Range',
        shortcut: 'age_range',
      },
      {
        id: 'd5b0ad4c-9a2b-407f-9b24-e5703e4de9e9',
        createdAt: new Date('2023-05-07T10:00:00.123Z').toISOString(),
        description:
          'A unit of time used to measure the duration of time, often expressed in the context of age or other temporal aspects. In demographic data, years can represent age groups or the timeframe for specific events.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Years',
        shortcut: 'years',
      },
      // gender
      {
        id: '3b0957e5-28bc-494a-92f3-e538e3ec2f56',
        createdAt: new Date('2023-06-07T10:00:00.123Z').toISOString(),
        description:
          'Indicates the gender of individuals, using "M" for Male and "F" for Female. This information is essential for demographic targeting and audience segmentation based on gender.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Gender',
        shortcut: 'gender',
      },
      // interest

      // Impressions
      {
        id: 'ea0c0ac8-a281-4c2b-951a-936708bc3541',
        createdAt: new Date('2023-08-07T10:00:00.123Z').toISOString(),
        description:
          'Impressions: The total number of times an ad or content is displayed to individuals within the target audience. It measures the reach and exposure of the marketing campaign, indicating how frequently the content is viewed by potential customers.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Impressions',
        shortcut: 'impressions',
      },
      {
        id: 'fd702ab0-ebcf-4e04-a915-53e52b371590',
        createdAt: new Date('2023-09-07T10:00:00.123Z').toISOString(),
        description:
          "Visibility Metric: 'Impressions' measures how often an ad is displayed to users, providing crucial insights into potential reach and exposure. It's foundational for understanding ad impact and analyzing campaign performance.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Visibility Metric',
        shortcut: 'visibility_metric',
      },
      // Clicks
      {
        id: '49eae644-e9b9-4e09-a0e1-a8fbbc6bb8da',
        createdAt: new Date('2023-10-07T10:00:00.123Z').toISOString(),
        description:
          "In digital advertising, a 'click' is a user's interaction with an ad. 'Clicks' represent the total number of user selections on an ad, signifying engagement and interest.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Click',
        shortcut: 'click',
      },
      // Spent
      {
        id: 'da895aa4-6fba-4d1f-a696-06f6f00581fa',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          "Expenditure Indicator reflects the total financial investment in an advertising campaign, covering costs for placements and promotions. This metric is crucial for budget assessment, cost-effectiveness, and optimizing future strategies. A higher 'Spent' value may indicate a more significant investment, influencing return on investment (ROI) analysis.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Expenditure Indicator',
        shortcut: 'expenditure_indicator',
      },

      // Total_Conversion
      // Approved_Conversion
      {
        id: '4ea7abb8-e015-4673-8d6d-68c8f664bd2a',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          "Conversion Approval Metric quantifies successful user actions in an advertising campaign, reflecting achieved conversions such as sign-ups or purchases. It's a crucial indicator of campaign effectiveness, guiding advertisers to assess strategy success and refine approaches for enhanced conversion rates.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Conversion Approval Metric',
        shortcut: 'conversion_approval_metric',
      },
      // others
      {
        id: '44337d0a-82e6-41ea-baea-27d1139e3073',
        createdAt: new Date('2023-07-07T10:00:00.123Z').toISOString(),
        description:
          'Demographics: The study of statistical data related to human populations, focusing on characteristics such as age, gender, and other factors. In the context of marketing, demographics provide insights into the composition of the target audience.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Demographics',
        shortcut: 'demographics',
      },
      {
        id: '85d2e23e-029a-45b7-9ae0-c76f02d2f4b0',
        createdAt: new Date('2023-07-07T10:00:00.123Z').toISOString(),
        description:
          "Return on Investment (ROI): A financial metric comparing advertising campaign gains to costs. The formula is the ratio of the difference between successful conversions ('Approved_Conversion' multiplied by 'Value_Per_Conversion') and the total campaign investment ('Spent') to 'Spent,' multiplied by 100. A positive ROI indicates profitability, while a negative ROI suggests potential optimization needs.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Return on Investment (ROI)',
        shortcut: 'roi',
      },
      {
        id: 'a10199bf-30b6-48ec-8c48-41cec87a4d18',
        createdAt: new Date('2023-07-07T10:00:00.123Z').toISOString(),
        description:
          "Engagement Rate: A metric combining 'Impressions' and 'Clicks' in an advertising campaign, calculated as the ratio of 'Clicks' to 'Impressions.' It gauges how effectively ads capture attention and encourage user interaction. A higher 'Engagement Rate' signifies greater audience interaction and interest. Advertisers use this metric to assess ad content effectiveness and optimize campaigns for improved interaction.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Engagement Rate',
        shortcut: 'engagement_rate',
      },
      {
        id: 'fadbc7ff-2698-4b13-84b5-4ee686a2a29b',
        createdAt: new Date('2023-07-07T10:00:00.123Z').toISOString(),
        description:
          "Marketing Metrics: A diverse set of measurements assessing the effectiveness of marketing strategies. These metrics provide insights into audience engagement, campaign performance, and overall impact on business objectives. Examples include 'Engagement Rate,' 'Click-Through Rate (CTR),' 'Conversion Rate,' and 'Impressions.' Advertisers leverage these metrics for data-driven decisions, campaign optimization, and alignment with organizational goals.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Marketing Metrics',
        shortcut: 'marketing_metrics',
      },
      {
        id: 'e16ffefa-cf62-4559-9fb2-2f99a8948700',
        createdAt: new Date('2023-07-07T10:00:00.123Z').toISOString(),
        description:
          "Cost-Efficiency Metric: Analyzing 'Spent,' 'Total_Conversion,' and 'Approved_Conversion' in an advertising campaign to evaluate budget effectiveness in achieving conversions. Advertisers use this metric for overall campaign assessment and resource optimization. A higher 'Cost-Efficiency' indicates effective budget utilization for approved conversions, while a lower efficiency suggests areas for improvement.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Cost-Efficiency',
        shortcut: 'cost_efficiency',
      },
      {
        id: '632ed456-69b7-4fbf-8c15-298ceefbb59c',
        createdAt: new Date('2023-07-07T10:00:00.123Z').toISOString(),
        description:
          "Conversion Rate: Calculated by dividing 'Approved_Conversion' by 'Total_Conversion' in an advertising campaign, it gauges how effectively the campaign transforms potential interest into actual conversions. A higher 'Conversion Rate' signifies successful achievement of desired user actions, enabling optimization for increased conversion success.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Conversion Rate',
        shortcut: 'conversion_rate',
      },

      {
        id: '122048fa-ad9a-4d7e-9184-86f57e5e7f41',
        createdAt: new Date('2023-11-07T10:00:00.123Z').toISOString(),
        description:
          'A metric is a quantifiable measure used for assessing, comparing, and tracking performance.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Metric',
        shortcut: 'metric',
      },
    ],
    relatedAnnotations: [
      // Gender
      {
        sourceId: '3b0957e5-28bc-494a-92f3-e538e3ec2f56', // Gender
        targetId: '44337d0a-82e6-41ea-baea-27d1139e3073', // Demographics
      },
      // Age
      {
        sourceId: '41900e8d-bbd5-40c5-a0e8-bf89c5a21ad0', // Age Range
        targetId: '44337d0a-82e6-41ea-baea-27d1139e3073', // Demographics
      },
      // Impressions
      {
        sourceId: 'fd702ab0-ebcf-4e04-a915-53e52b371590', // Visibility Metric
        targetId: '122048fa-ad9a-4d7e-9184-86f57e5e7f41', // Metric
      },
      // Clicks
      // Approved_Conversion
      {
        sourceId: '4ea7abb8-e015-4673-8d6d-68c8f664bd2a', // Engagement Metric
        targetId: '85d2e23e-029a-45b7-9ae0-c76f02d2f4b0', // Return on Investment (ROI)
      },
      // Spent
      {
        sourceId: 'da895aa4-6fba-4d1f-a696-06f6f00581fa', // Expenditure Indicator
        targetId: '85d2e23e-029a-45b7-9ae0-c76f02d2f4b0', // Return on Investment (ROI)
      },
      {
        sourceId: '85d2e23e-029a-45b7-9ae0-c76f02d2f4b0', // Return on Investment (ROI)
        targetId: '95fc967d-7454-4ced-b3e5-b836fb856473', // Financial metric
      },
      // others
      {
        sourceId: 'a10199bf-30b6-48ec-8c48-41cec87a4d18', // Engagement Rate
        targetId: 'fadbc7ff-2698-4b13-84b5-4ee686a2a29b', // Marketing Metrics
      },
      {
        sourceId: 'fadbc7ff-2698-4b13-84b5-4ee686a2a29b', // Marketing Metrics
        targetId: '122048fa-ad9a-4d7e-9184-86f57e5e7f41', // Metric
      },
      {
        sourceId: 'e16ffefa-cf62-4559-9fb2-2f99a8948700', // Cost-Efficiency
        targetId: '95fc967d-7454-4ced-b3e5-b836fb856473', // Financial metric
      },
      {
        sourceId: '632ed456-69b7-4fbf-8c15-298ceefbb59c', // Conversion Rate
        targetId: '122048fa-ad9a-4d7e-9184-86f57e5e7f41', // Metric
      },

      {
        sourceId: 'ea0c0ac8-a281-4c2b-951a-936708bc3541', // Conversion Rate
        targetId: 'a10199bf-30b6-48ec-8c48-41cec87a4d18', // Engagement Rate
      },

      {
        sourceId: '49eae644-e9b9-4e09-a0e1-a8fbbc6bb8da', // Click
        targetId: 'a10199bf-30b6-48ec-8c48-41cec87a4d18', // Engagement Rate
      },
    ],
    columnData: [
      {
        columnName: 'ad_id',
        columnDescription:
          'Ad ID: A unique identifier for each advertisement in the marketing campaign.',
      },
      {
        columnName: 'xyz_campaign_id',
        columnDescription:
          'XYZ Campaign ID: An identifier for the XYZ campaign to which the advertisement belongs.',
      },
      {
        columnName: 'fb_campaign_id',
        columnDescription:
          'Facebook Campaign ID: An identifier for the Facebook campaign associated with the advertisement.',
      },
      {
        columnName: 'age',
        columnDescription:
          'Age: The age group or range of the target audience for the advertisement.',
      },
      {
        columnName: 'gender',
        columnDescription:
          'Gender: The gender category of the target audience for the advertisement.',
      },
      {
        columnName: 'interest',
        columnDescription:
          'Interest: The specific area of interest or topic targeting the advertisement.',
      },
      {
        columnName: 'Impressions',
        columnDescription:
          'Impressions: The number of times the advertisement was viewed or displayed.',
      },
      {
        columnName: 'Clicks',
        columnDescription:
          'Clicks: The number of clicks received on the advertisement, indicating user interaction.',
      },
      {
        columnName: 'Spent',
        columnDescription:
          'Spent: The amount of money spent on the advertisement campaign.',
      },
      {
        columnName: 'Total_Conversion',
        columnDescription:
          'Total Conversion: The total number of conversions attributed to the advertisement, including approved and unapproved conversions.',
      },
      {
        columnName: 'Approved_Conversion',
        columnDescription:
          'Approved Conversion: The number of conversions that have been approved and validated.',
      },
    ],
  },
  {
    datasetName: 'Ecommerce Customers',
    datasetDescription: 'Ecommerce Customers dataset description',
    firebaseDatasetID: 'i11dedyswB5bQ7RVTkD0',
    firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    columnAnnotationData: [
      // Email
      {
        columnName: 'Email',
        annotationId: '0f986493-4776-4886-9553-f82e55053f5e', // Email
      },

      // Address
      {
        columnName: 'Address',
        annotationId: '59882f52-7580-4456-93a4-6b023db85316', // Address
      },
      // Avatar
      {
        columnName: 'Avatar',
        annotationId: 'be25637f-253d-4747-baad-58d57bb3f713', // Avatar
      },
      // Avg. Session Length
      {
        columnName: 'Avg. Session Length',
        annotationId: '74a1ced1-a59b-44d2-9e8c-397c5de04e54', // Session Length
      },
      // Time on App
      {
        columnName: 'Time on App',
        annotationId: 'cc451d31-f42c-4194-b116-e3312c6893bf', // Time on App
      },
      // Time on Website
      {
        columnName: 'Time on Website',
        annotationId: '1f1f1a0c-4ba7-4063-b3bc-46e3e8487a54', // Time on Website
      },
      // Length of Membership
      {
        columnName: 'Length of Membership',
        annotationId: 'eee25c98-a522-4473-8c64-e083e95fb4e9', // Length of Membership
      },
      // Yearly Amount Spent
      {
        columnName: 'Yearly Amount Spent',
        annotationId: 'd0b7da65-4b3a-4a88-8b84-056cbf9cc1c6', // Yearly Amount Spent
      },
      {
        columnName: 'Yearly Amount Spent',
        annotationId: 'f33b98f1-30b2-4064-9bce-376fe958d6c8', // Revenue Generation Metrics
      },
    ],
    annotationData: [
      // Email

      {
        id: '0f986493-4776-4886-9553-f82e55053f5e',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'Email: Contains the unique email addresses of users. It serves as a primary identifier and communication channel within the system, crucial for user-specific interactions, account verification, and communication purposes.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Email',
        shortcut: 'email',
      },
      // Address
      {
        id: '59882f52-7580-4456-93a4-6b023db85316',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'Address: Represents the physical address associated with user accounts. It serves as a location identifier and is essential for user-specific interactions, account verification, and communication within the system.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Address',
        shortcut: 'address',
      },
      // Avatar
      {
        id: 'be25637f-253d-4747-baad-58d57bb3f713',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'Avatar: Represents visual profile images associated with users within the system. While not a direct identifier, avatars contribute to personalization and recognition, enhancing the user experience.',
        shortcut: 'avatar',
        name: 'Avatar',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
      },
      // Avg. Session Length
      {
        id: '74a1ced1-a59b-44d2-9e8c-397c5de04e54',
        createdAt: new Date('2023-03-07T10:00:00.123Z').toISOString(),
        description:
          'The duration of time a user actively interacts with a system or application during a single session. It measures the engagement and usability of the platform, reflecting how long users typically remain involved and engaged in their activities.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Session Length',
        shortcut: 'session_length',
      },
      // Time on App
      {
        id: 'cc451d31-f42c-4194-b116-e3312c6893bf',
        createdAt: new Date('2023-04-07T10:00:00.123Z').toISOString(),
        description:
          "Time on App: The total amount of time users spend actively engaging with a mobile application. This metric measures the user's investment of time and attention on the app, providing insights into user engagement, satisfaction, and the overall appeal of the mobile experience.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Time on App',
        shortcut: 'time_on_app',
      },
      // Time on Website
      {
        id: '1f1f1a0c-4ba7-4063-b3bc-46e3e8487a54',
        createdAt: new Date('2023-05-07T10:00:00.123Z').toISOString(),
        description:
          "Time on Website: The total amount of time users spend actively engaging with a website. This metric measures the user's investment of time and attention on the website, providing insights into user engagement, satisfaction, and the overall appeal of the online experience.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Time on Website',
        shortcut: 'time_on_website',
      },
      // Length of Membership
      {
        id: 'eee25c98-a522-4473-8c64-e083e95fb4e9',
        createdAt: new Date('2023-06-07T10:00:00.123Z').toISOString(),
        description:
          'Length of Membership: The duration of time a user has been a member or subscriber to a service or platform. This metric reflects user loyalty and long-term commitment, providing insights into the retention and satisfaction levels of the user base.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Length of Membership',
        shortcut: 'membership_length',
      },
      // Yearly Amount Spent

      {
        id: 'd0b7da65-4b3a-4a88-8b84-056cbf9cc1c6',
        createdAt: new Date('2023-07-07T10:00:00.123Z').toISOString(),
        description:
          "Yearly Amount Spent: The total monetary expenditure by a user within a year on a service, product, or platform. This metric measures the user's financial investment, providing insights into spending patterns, customer value, and the overall economic contribution of individual users.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Yearly Amount Spent',
        shortcut: 'yearly_spending',
      },

      {
        id: 'f33b98f1-30b2-4064-9bce-376fe958d6c8',
        createdAt: new Date('2023-07-07T10:00:00.123Z').toISOString(),
        description:
          'Serves as a key metric for revenue generation. Analyzing this, along with other metrics, can help identify high-value customers and optimize strategies to increase spending.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Revenue Generation Metrics',
        shortcut: 'revenue_metrics',
      },

      // others
      {
        id: 'd37c97fa-1f80-470b-90ae-2b3070ccc0ee',
        createdAt: new Date('2023-08-07T10:00:00.123Z').toISOString(),
        description:
          "User Profile: A representation of an individual user within a system, created by combining information from various columns. The 'Email' serves as a unique identifier and communication channel. 'Address' provides the physical location associated with the user. 'Avatar' is a visual representation or profile image enhancing personalization and recognition.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'User Profile',
        shortcut: 'user_profile',
      },
      {
        id: 'fbf1262c-7022-4293-a88a-4cd942f9dfc5',
        createdAt: new Date('2023-08-07T10:00:00.123Z').toISOString(),
        description:
          "Engagement Metrics: Provide insights into user interaction, including 'Avg. Session Length,' 'Time on App,' and 'Time on Website.' These metrics help gauge user activity and engagement with the app and website.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Engagement Metrics',
        shortcut: 'engagement_metrics',
      },

      {
        id: 'a751518f-18db-4098-ac01-72e9028fa953',
        createdAt: new Date('2023-08-07T10:00:00.123Z').toISOString(),
        description:
          "Membership Dynamics Metrics: 'Length of Membership' and 'Yearly Amount Spent' can be used to analyze the relationship between user loyalty and spending. Longer membership durations may correlate with higher yearly spending, indicating a strong customer relationship.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Membership Dynamics Metrics',
        shortcut: 'membership_metrics',
      },
    ],
    relatedAnnotations: [
      // Email
      {
        sourceId: '0f986493-4776-4886-9553-f82e55053f5e', // Email
        targetId: 'd37c97fa-1f80-470b-90ae-2b3070ccc0ee', // User Profile
      },
      // Address
      {
        sourceId: '59882f52-7580-4456-93a4-6b023db85316', // Address
        targetId: 'd37c97fa-1f80-470b-90ae-2b3070ccc0ee', // User Profile
      },
      // Avatar
      {
        sourceId: 'be25637f-253d-4747-baad-58d57bb3f713', // Avatar
        targetId: 'd37c97fa-1f80-470b-90ae-2b3070ccc0ee', // User Profile
      },

      // Avg. Session Length
      {
        sourceId: '74a1ced1-a59b-44d2-9e8c-397c5de04e54', // Session Length
        targetId: 'fbf1262c-7022-4293-a88a-4cd942f9dfc5', // Engagement Metrics
      },
      // Time on App
      {
        sourceId: 'cc451d31-f42c-4194-b116-e3312c6893bf', // Time on App
        targetId: 'fbf1262c-7022-4293-a88a-4cd942f9dfc5', // Engagement Metrics
      },
      // Time on Website
      {
        sourceId: '1f1f1a0c-4ba7-4063-b3bc-46e3e8487a54', // Time on Website
        targetId: 'fbf1262c-7022-4293-a88a-4cd942f9dfc5', // Engagement Metrics
      },
      // Yearly Amount Spent
      {
        sourceId: 'f33b98f1-30b2-4064-9bce-376fe958d6c8', // Revenue Generation Metrics
        targetId: '122048fa-ad9a-4d7e-9184-86f57e5e7f41', // Metric
      },
      {
        sourceId: 'd0b7da65-4b3a-4a88-8b84-056cbf9cc1c6', // 	Yearly Amount Spent
        targetId: 'a751518f-18db-4098-ac01-72e9028fa953', // Membership Dynamics Metrics
      },

      // Length of Membership
      {
        sourceId: 'eee25c98-a522-4473-8c64-e083e95fb4e9', // Length of Membership
        targetId: 'a751518f-18db-4098-ac01-72e9028fa953', // Membership Dynamics Metrics
      },
      // Others
      {
        sourceId: 'fbf1262c-7022-4293-a88a-4cd942f9dfc5', // Engagement Metrics
        targetId: '122048fa-ad9a-4d7e-9184-86f57e5e7f41', // Metric
      },
      {
        sourceId: 'a751518f-18db-4098-ac01-72e9028fa953', //	Membership Dynamics Metrics
        targetId: '122048fa-ad9a-4d7e-9184-86f57e5e7f41', // Metric
      },
    ],
    columnData: [
      {
        columnName: 'Email',
        columnDescription:
          'Email: The email address of the user, serving as a unique identifier and means of communication.',
      },

      {
        columnName: 'Address',
        columnDescription:
          "Address: The physical address associated with the user's account, providing location information.",
      },

      {
        columnName: 'Avatar',
        columnDescription:
          "Avatar: Represents the user's profile image or visual representation within the system.",
      },

      {
        columnName: 'Avg. Session Length',
        columnDescription:
          'Avg. Session Length: The average duration of user sessions on the application or website.',
      },

      {
        columnName: 'Time on App',
        columnDescription:
          'Time on App: The total time users spend actively engaged with the mobile application.',
      },

      {
        columnName: 'Time on Website',
        columnDescription:
          'Time on Website: The total time users spend actively engaged with the website.',
      },

      {
        columnName: 'Length of Membership',
        columnDescription:
          'Length of Membership: The duration for which a user has been a member or subscriber.',
      },

      {
        columnName: 'Yearly Amount Spent',
        columnDescription:
          'Yearly Amount Spent: The total expenditure by the user on the platform over the course of a year.',
      },
    ],
  },
  {
    datasetName: 'customer_conversion_traing_dataset',
    datasetDescription:
      'customer_conversion_traing_dataset dataset description',
    firebaseDatasetID: 'utwlXasdEiVAE0waBhFC5VSasdads',
    firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    columnAnnotationData: [
      // LeadID column
      {
        columnName: 'LeadID',
        annotationId: 'dddef883-cf22-4b62-811b-ecfb78b0a159', // Entity Identifier
      },
      // Age column
      {
        columnName: 'Age',
        annotationId: 'd5b0ad4c-9a2b-407f-9b24-e5703e4de9e9', // years
      },
      {
        columnName: 'Age',
        annotationId: '5fa13e72-4f72-406e-acbf-85c9e4ffbbc8', // Age Classification
      },

      // Gender column
      {
        columnName: 'Gender',
        annotationId: '44337d0a-82e6-41ea-baea-27d1139e3073', // Demographics
      },
      {
        columnName: 'Gender',
        annotationId: 'bf32c76a-0de7-4f37-bda9-23a8f76ad01f', // Gender Identity
      },

      // Location column
      {
        columnName: 'Location',
        annotationId: 'f5874080-8c2a-45b3-8f01-60a294197bfa', // Location
      },
      // LeadSource column
      {
        columnName: 'LeadSource',
        annotationId: 'f5f668d3-e13c-471c-a7a9-aa41ab2464ad', // Lead Source
      },
      // TimeSpent (minutes) column
      {
        columnName: 'TimeSpent (minutes)',
        annotationId: 'd71277d5-d1f8-403b-b9b4-21675c5bc4ab', // Time Spent
      },

      {
        columnName: 'TimeSpent (minutes)',
        annotationId: '0f8ab137-cd8f-4ed7-aa90-0c5aa79dabad', // Minutes
      },

      // PagesViewed column
      {
        columnName: 'PagesViewed',
        annotationId: '17c6ffbc-e28a-452b-8e5c-4708fd7aa577', // Pages Viewed
      },
      // LeadStatus column
      {
        columnName: 'LeadStatus',
        annotationId: '91b3f78b-90dc-4366-ad21-e927ba1bb1bd', // Lead Status
      },

      // EmailSent column
      {
        columnName: 'EmailSent',
        annotationId: '64cebbee-5de7-4cf3-b9e3-e0d4f3fc64c9', // Email Sent
      },
      // DeviceType column
      {
        columnName: 'DeviceType',
        annotationId: '13486a88-2c88-4fc9-9a3e-f3e45557fd2e', // DeviceType
      },
      // ReferralSource column
      {
        columnName: 'ReferralSource',
        annotationId: '0b7f5436-6382-4d7d-a938-06109eb537bd', // Referral Source
      },
      // FormSubmissions column
      {
        columnName: 'FormSubmissions',
        annotationId: '876fc780-0d6b-492f-a7b6-8a969cfe90a1', // Form Submissions
      },
      // Downloads column
      {
        columnName: 'Downloads',
        annotationId: '9b0d51db-514e-4fc0-8ab9-4fb289a71d02', // Downloads
      },
      // CTR_ProductPage column
      {
        columnName: 'CTR_ProductPage',
        annotationId: 'e1fe4a3a-bf94-4ffb-98b7-28c828280613', // CTR Product Page
      },
      // ResponseTime column
      {
        columnName: 'ResponseTime',
        annotationId: 'c7f77240-d7de-4897-8672-9e67f761f9e4', // Response time
      },
    ],
    annotationData: [
      // LeadID
      // Age
      {
        id: '5fa13e72-4f72-406e-acbf-85c9e4ffbbc8',
        createdAt: new Date('2023-04-07T10:00:00.123Z').toISOString(),
        description:
          'Annotates the age of a person or entity, providing information about their life stage.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Age Classification',
        shortcut: 'age_classification',
      },
      // Gender
      {
        id: 'bf32c76a-0de7-4f37-bda9-23a8f76ad01f',
        createdAt: new Date('2023-04-07T12:30:00.456Z').toISOString(),
        description:
          'Annotates the gender information of an individual, indicating their biological sex or gender identity.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Gender Identity',
        shortcut: 'gender_identity',
      },
      // Location column
      {
        id: 'f5874080-8c2a-45b3-8f01-60a294197bfa',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the geographical location or address of an individual or entity.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Location',
        shortcut: 'location',
      },
      // LeadSource column
      {
        id: 'f5f668d3-e13c-471c-a7a9-aa41ab2464ad',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the source or channel through which a lead was acquired.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Lead Source',
        shortcut: 'lead_source',
      },
      // TimeSpent (minutes) column

      {
        id: 'd71277d5-d1f8-403b-b9b4-21675c5bc4ab',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the amount of time, measured in minutes, spent on a particular activity or platform.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Time Spent',
        shortcut: 'time_spent',
      },

      {
        id: '8f8c99ee-dfc6-4774-95f1-9f8ab469a7b9',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'Represents the duration or amount of time taken for a particular process or activity.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Time',
        shortcut: 'time',
      },

      {
        id: '0f8ab137-cd8f-4ed7-aa90-0c5aa79dabad',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the unit of time, measured in minutes.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Minutes',
        shortcut: 'minutes',
      },
      // PagesViewed column
      {
        id: '17c6ffbc-e28a-452b-8e5c-4708fd7aa577',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the number of pages viewed or accessed by an individual or entity.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Pages Viewed',
        shortcut: 'pages_viewed',
      },
      {
        id: '0b1463d9-55ee-4335-b935-c0c115becd59',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description: 'Represents a page within a system or website.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Page',
        shortcut: 'page',
      },
      // LeadStatus column
      {
        id: '91b3f78b-90dc-4366-ad21-e927ba1bb1bd',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the current status of a lead (e.g., qualified, unqualified, contacted).',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Lead Status',
        shortcut: 'lead_status',
      },
      // EmailSent column
      {
        id: '64cebbee-5de7-4cf3-b9e3-e0d4f3fc64c9',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of whether an email has been sent to a lead (e.g., true for sent, false for not sent).',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Email Sent',
        shortcut: 'email_sent',
      },
      {
        id: '608cc348-5142-4ca8-8db1-6b55572da19c',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'Represents whether an email has been sent to a lead (e.g., true for sent, false for not sent).',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Email',
        shortcut: 'email',
      },
      // DeviceType column
      {
        id: '13486a88-2c88-4fc9-9a3e-f3e45557fd2e',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the type of device used by an individual or entity (e.g., mobile, desktop).',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Device Type',
        shortcut: 'device_type',
      },
      {
        id: 'f88741c0-bc1c-420e-b941-f80e04fea4e0',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'Represents the use of a mobile device by an individual or entity.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Mobile',
        shortcut: 'mobile',
      },
      {
        id: '870cd596-a278-4afd-b746-b701fd9296a7',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'Represents the use of a desktop device by an individual or entity.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Desktop',
        shortcut: 'desktop',
      },
      // ReferralSource column
      {
        id: '0b7f5436-6382-4d7d-a938-06109eb537bd',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the source from which a lead was referred or directed.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Referral Source',
        shortcut: 'referral_source',
      },
      // FormSubmissions column
      {
        id: '876fc780-0d6b-492f-a7b6-8a969cfe90a1',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the number of forms submitted by a lead.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Form Submissions',
        shortcut: 'form_submissions',
      },
      {
        id: 'de2e8996-3f70-47a6-9269-692c8308155a',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'An entity representing a structured document with fields to collect and store information.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Form',
        shortcut: 'form',
      },
      // Downloads column
      {
        id: '9b0d51db-514e-4fc0-8ab9-4fb289a71d02',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the number of downloads initiated or completed by a lead.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Downloads',
        shortcut: 'downloads',
      },
      // CTR_ProductPage column
      {
        id: 'e1fe4a3a-bf94-4ffb-98b7-28c828280613',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the Click-Through Rate (CTR) specific to the product page, indicating the ratio of clicks to impressions.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'CTR Product Page',
        shortcut: 'ctr_product_page',
      },
      {
        id: '85b55644-e841-40d4-bf60-697987f453dc',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'An entity representing Click-Through Rate (CTR), a metric indicating the ratio of clicks to impressions.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Click-Through Rate (CTR)',
        shortcut: 'ctr',
      },
      // ResponseTime column
      {
        id: 'c7f77240-d7de-4897-8672-9e67f761f9e4',
        createdAt: '2023-01-07T10:00:00.123Z',
        description:
          'A representation of the time taken to respond to a lead, often measured in minutes.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Response Time',
        shortcut: 'response_time',
      },
    ],
    relatedAnnotations: [
      // ResponseTime
      {
        sourceId: 'c7f77240-d7de-4897-8672-9e67f761f9e4', // ResponseTime
        targetId: '8f8c99ee-dfc6-4774-95f1-9f8ab469a7b9', // Time
      },
      // CTR Product Page
      {
        sourceId: 'e1fe4a3a-bf94-4ffb-98b7-28c828280613', // CTR Product Page
        targetId: '85b55644-e841-40d4-bf60-697987f453dc', // Click-Through Rate (CTR)
      },
      {
        sourceId: '85b55644-e841-40d4-bf60-697987f453dc', // Click-Through Rate (CTR)
        targetId: '95fc967d-7454-4ced-b3e5-b836fb856473', // Financial Metric
      },
      // Form Submissions
      {
        sourceId: '876fc780-0d6b-492f-a7b6-8a969cfe90a1', // Form Submissions
        targetId: 'de2e8996-3f70-47a6-9269-692c8308155a', // Form
      },
      // Device Type
      {
        sourceId: 'f88741c0-bc1c-420e-b941-f80e04fea4e0', // Mobile
        targetId: '13486a88-2c88-4fc9-9a3e-f3e45557fd2e', // Device Type
      },
      {
        sourceId: '870cd596-a278-4afd-b746-b701fd9296a7', // Desktop
        targetId: '13486a88-2c88-4fc9-9a3e-f3e45557fd2e', // Device Type
      },

      // EmailSent
      {
        sourceId: '64cebbee-5de7-4cf3-b9e3-e0d4f3fc64c9', // EmailSent
        targetId: '608cc348-5142-4ca8-8db1-6b55572da19c', // Email
      },

      // Pages Viewed
      {
        sourceId: '17c6ffbc-e28a-452b-8e5c-4708fd7aa577', // Pages Viewed
        targetId: '0b1463d9-55ee-4335-b935-c0c115becd59', // Page
      },

      // TimeSpent (minutes)
      {
        sourceId: 'd71277d5-d1f8-403b-b9b4-21675c5bc4ab', // Time Spent
        targetId: '8f8c99ee-dfc6-4774-95f1-9f8ab469a7b9', // Time
      },
    ],
    columnData: [
      {
        columnName: 'LeadID',
        columnDescription:
          'A unique identifier or code assigned to each lead for identification purposes.',
      },
      {
        columnName: 'Age',
        columnDescription: 'The age of the lead.',
      },
      {
        columnName: 'Gender',
        columnDescription: 'The gender of the lead (e.g., male, female).',
      },
      {
        columnName: 'Location',
        columnDescription: 'The geographical location or address of the lead.',
      },
      {
        columnName: 'LeadSource',
        columnDescription:
          'The specific source or channel through which the lead was acquired.',
      },
      {
        columnName: 'TimeSpent (minutes)',
        columnDescription:
          'The amount of time, measured in minutes, that the lead spent on a particular activity or platform.',
      },
      {
        columnName: 'PagesViewed',
        columnDescription:
          'The number of pages viewed or accessed by the lead.',
      },
      {
        columnName: 'LeadStatus',
        columnDescription:
          'The current status of the lead (e.g., qualified, unqualified, contacted).',
      },
      {
        columnName: 'EmailSent',
        columnDescription:
          'Indicates whether an email has been sent to the lead (e.g., true for sent, false for not sent).',
      },
      {
        columnName: 'DeviceType',
        columnDescription:
          'The type of device used by the lead (e.g., mobile, desktop).',
      },
      {
        columnName: 'ReferralSource',
        columnDescription:
          'The source from which the lead was referred or directed.',
      },
      {
        columnName: 'FormSubmissions',
        columnDescription: 'The number of forms submitted by the lead.',
      },
      {
        columnName: 'Downloads',
        columnDescription:
          'The number of downloads initiated or completed by the lead.',
      },
      {
        columnName: 'CTR_ProductPage',
        columnDescription:
          'Click-Through Rate (CTR) specific to the product page, indicating the ratio of clicks to impressions.',
      },
      {
        columnName: 'ResponseTime',
        columnDescription:
          'The time taken to respond to the lead, often measured in minutes.',
      },
    ],
  },
  {
    datasetName: 'conversion_data',
    datasetDescription: 'conversion_data dataset description',
    firebaseDatasetID: 'uxwlXEiVAE0waBhFC5VS',
    firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
    columnAnnotationData: [
      // Country column
      {
        columnName: 'country',
        annotationId: '395578a9-7132-4911-afe6-7094ff0a2fa2', // Country
      },
      // Age column
      {
        columnName: 'age',
        annotationId: 'd5b0ad4c-9a2b-407f-9b24-e5703e4de9e9', // years
      },
      {
        columnName: 'age',
        annotationId: '5fa13e72-4f72-406e-acbf-85c9e4ffbbc8', // Age Classification
      },
      // new_user
      {
        columnName: 'new_user',
        annotationId: '162705a1-6930-4824-a0b2-ee5396236945', // New User
      },
      // Source
      {
        columnName: 'source',
        annotationId: 'a32f9fa9-7b3f-40cd-934d-b3f89077893d', // Source
      },
      // Total Pages Visited column
      {
        columnName: 'total_pages_visited',
        annotationId: '6cc25fd3-8ba8-4748-bde5-ee26f7617016', // Total Pages Visited
      },
      // Converted column
      {
        columnName: 'converted',
        annotationId: 'cccac355-fdbe-4686-9a43-c34331f63c76', // Conversion Outcome
      },
      {
        columnName: 'converted',
        annotationId: 'bed6d944-88e6-4193-9fc7-1cf111487237', // Conversion
      },
      {
        columnName: 'converted',
        annotationId: '4d230c7e-daf4-4111-b808-c6060536f1e8', // flag
      },
    ],
    annotationData: [
      // Country column
      {
        id: '395578a9-7132-4911-afe6-7094ff0a2fa2',
        createdAt: new Date('2023-02-07T10:00:00.123Z').toISOString(),
        description:
          'A representation of the country associated with the lead or user.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Country',
        shortcut: 'country',
      },
      // Age column

      // New User column
      {
        id: '162705a1-6930-4824-a0b2-ee5396236945',
        createdAt: new Date('2023-01-07T10:00:00.123Z').toISOString(),
        description:
          'Indicates whether the lead or user is a new user (e.g., true for new, false for existing).',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'New User',
        shortcut: 'new_user',
      },
      {
        id: '7ee31ddf-06e8-4dd7-8ec4-942ed9085de5',
        createdAt: new Date('2023-03-07T10:00:00.123Z').toISOString(),
        description: 'Represents a user of the system or platform.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'User',
        shortcut: 'user',
      },

      // Source column
      {
        id: 'a32f9fa9-7b3f-40cd-934d-b3f89077893d',
        createdAt: new Date('2023-04-07T10:00:00.123Z').toISOString(),
        description:
          'A representation of the specific source or channel through which the lead or user originated.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Source',
        shortcut: 'source',
      },

      // Total Pages Visited column
      {
        id: '6cc25fd3-8ba8-4748-bde5-ee26f7617016',
        createdAt: new Date('2023-05-07T10:00:00.123Z').toISOString(),
        description:
          'A representation of the total number of pages visited or accessed by the lead or user.',
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Total Pages Visited',
        shortcut: 'total_pages_visited',
      },

      // Converted column
      {
        id: 'cccac355-fdbe-4686-9a43-c34331f63c76',
        createdAt: new Date('2023-04-07T17:45:00.789Z').toISOString(),
        description:
          "Annotates the lead or user's conversion outcome, providing information on whether they achieved a predefined goal.",
        firebaseUserUID: 'xqcO5YrSc1gb6bf9rVF41Rwz30s2',
        name: 'Conversion Outcome',
        shortcut: 'conversion_outcome',
      },
    ],
    relatedAnnotations: [
      // New User column
      {
        sourceId: '162705a1-6930-4824-a0b2-ee5396236945', // New User
        targetId: '7ee31ddf-06e8-4dd7-8ec4-942ed9085de5', // User
      },

      // Total Pages Visited column
      {
        sourceId: '6cc25fd3-8ba8-4748-bde5-ee26f7617016', // Total Pages Visited
        targetId: '0b1463d9-55ee-4335-b935-c0c115becd59', // Page
      },
    ],
    columnData: [
      {
        columnName: 'country',
        columnDescription: 'The country associated with the lead or user.',
      },
      {
        columnName: 'age',
        columnDescription: 'The age of the lead or user.',
      },
      {
        columnName: 'new_user',
        columnDescription:
          'Indicates whether the lead or user is a new user (e.g., true for new, false for existing).',
      },
      {
        columnName: 'source',
        columnDescription:
          'The specific source or channel through which the lead or user originated.',
      },
      {
        columnName: 'total_pages_visited',
        columnDescription:
          'The total number of pages visited or accessed by the lead or user.',
      },
      {
        columnName: 'converted',
        columnDescription:
          'Indicates whether the lead or user has been converted (e.g., true for converted, false for not converted).',
      },
    ],
  },
];

@Injectable()
export class SeedNeo4j {
  constructor(private readonly queryRepository: QueryRepository) {}

  async createAnnotation() {
    // dataset part
    // Check if the dataset already exists
    for (const dataset of datasets) {
      const existingDataset = await this.queryRepository
        .initQuery()
        .match([
          node('dataset:Dataset', 'Dataset', {
            firebaseDatasetID: dataset.firebaseDatasetID,
          }),
        ])
        .return('dataset')
        .limit(1)
        .run();

      if (existingDataset.length === 0) {
        // Create the Dataset node if it doesn't exist

        const createDataset = await this.queryRepository
          .initQuery()
          .createNode('Dataset', 'Dataset', {
            datasetName: dataset.datasetName,
            datasetDescription: dataset.datasetDescription,
            firebaseDatasetID: dataset.firebaseDatasetID,
            firebaseUserUID: dataset.firebaseUserUID,
          })
          .return('Dataset')
          .run();
        console.log('createDataset', createDataset);
      }
      // annotations part

      // column part
      for (const column of dataset.columnData) {
        // Check if the Column node of this dataset already exists
        const existingColumn = await this.queryRepository
          .initQuery()
          .match([
            node('dataset:Dataset', 'Dataset', {
              firebaseDatasetID: dataset.firebaseDatasetID,
            }),
            relation('out', 'rel', 'HAS_COLUMN'),
            node('column:Column', 'Column', {
              columnName: column.columnName,
            }),
          ])
          .return('column')
          .run();

        if (existingColumn.length === 0) {
          // Create the Column node if it doesn't exist
          const createColumn = await this.queryRepository
            .initQuery()
            .match([
              node('dataset:Dataset', 'Dataset', {
                firebaseDatasetID: dataset.firebaseDatasetID,
              }),
            ])
            .create([
              node('dataset'),
              relation('out', 'rel', 'HAS_COLUMN'),
              node('column:Column', 'Column', {
                columnName: column.columnName,
                columnDescription: column.columnDescription,
              }),
            ])
            .return('column')
            .run();

          console.log('createColumn', createColumn);
        }
      }

      // annotation part
      for (const annotation of dataset.annotationData) {
        const formattedDate = new Date(annotation.createdAt).toLocaleString(
          'en-US',
          {
            month: 'numeric',
            day: 'numeric',
            year: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: true,
          },
        );
        annotation.createdAt = formattedDate;

        // Check if the annotation already exists
        const existingAnnotation = await this.queryRepository
          .initQuery()
          .match([
            node('annotation:Annotation', 'Annotation', {
              id: annotation.id,
            }),
          ])
          .return('annotation')
          .first();

        if (existingAnnotation) {
        } else {
          // Create the annotation
          const createAnnotation = await this.queryRepository
            .initQuery()
            .createNode('Annotation', 'Annotation', annotation)
            .return('Annotation')
            .run();

          console.log('createAnnotation', createAnnotation);
        }
      }
      // Create RELATED_TO relationships forming a chain
      for (const relationship of dataset.relatedAnnotations) {
        const sourceId = relationship.sourceId;
        const targetId = relationship.targetId;

        // Check if the relationship already exists
        const checkRelationshipQuery = await this.queryRepository
          .initQuery()
          .match([
            node('source:Annotation', 'Annotation', { id: sourceId }),
            relation('out', 'RELATED_TO', 'RELATED_TO'),
            node('target:Annotation', 'Annotation', { id: targetId }),
          ])
          .return(['source, target'])
          .run();
        if (checkRelationshipQuery.length === 0) {
          // Relationship doesn't exist, so create it
          await this.queryRepository
            .initQuery()
            .match([node('source:Annotation', 'Annotation', { id: sourceId })])
            .match([node('target:Annotation', 'Annotation', { id: targetId })])
            .create([
              node('source'),
              relation('out', 'RELATED_TO', 'RELATED_TO'),
              node('target'),
            ])
            .return(['source, target'])
            .run();
          console.log(
            `Created RELATED_TO relationship between ${sourceId} and ${targetId}:`,
          );
        }
      }

      // Loop through the columnAnnotationData array and create relationships
      for (const { columnName, annotationId } of dataset.columnAnnotationData) {
        // Check if the relationship already exists

        const existingRelationship = await this.queryRepository
          .initQuery()
          .match([
            // Match the dataset
            node('dataset:Dataset', 'Dataset', {
              firebaseDatasetID: dataset.firebaseDatasetID,
            }),
          ])
          .match([
            // Match the specified column and its relationships within the dataset
            node('dataset'),
            relation('out', 'rel', 'HAS_COLUMN'),
            node('column:Column', 'Column', {
              columnName: columnName,
            }),
            relation('out', 'is_ANNOTATED', 'ANNOTATED_WITH'),
            node('annotation:Annotation', 'Annotation', {
              id: annotationId,
            }),
          ])
          .return(['column', 'annotation'])
          .run();

        if (existingRelationship.length === 0) {
          // Relationship doesn't exist, so create it
          await this.queryRepository
            .initQuery()
            .match([
              // Match the dataset
              node('dataset:Dataset', 'Dataset', {
                firebaseDatasetID: dataset.firebaseDatasetID,
              }),
            ])
            .match([
              // Match the specified column within the dataset
              node('dataset'),
              relation('out', 'rel', 'HAS_COLUMN'),
              node('column:Column', 'Column', {
                columnName: columnName,
              }),
            ])
            .match([
              // Match the specified annotation
              node('annotation:Annotation', 'Annotation', {
                id: annotationId,
              }),
            ])
            .create([
              // Create a relationship between the column and the annotation
              node('column'),
              relation('out', '', 'ANNOTATED_WITH'),
              node('annotation'),
            ])
            .run();

          console.log(
            `Created ANNOTATED_WITH relationship between column '${columnName}' and annotation '${annotationId}'`,
          );
        }
      }
    }
  }

  async testing(numberOfAnnotations: number) {
    console.time('testing'); // Start the timer

    // dataset part
    // Check if the dataset already exists
    const dataset = datasets[0];
    const existingDataset = await this.queryRepository
      .initQuery()
      .match([
        node('dataset:Dataset', 'Dataset', {
          firebaseDatasetID: dataset.firebaseDatasetID,
        }),
      ])
      .return('dataset')
      .limit(1)
      .run();

    if (existingDataset.length === 0) {
      // Create the Dataset node if it doesn't exist

      await this.queryRepository
        .initQuery()
        .createNode('Dataset', 'Dataset', {
          datasetName: dataset.datasetName,
          datasetDescription: dataset.datasetDescription,
          firebaseDatasetID: dataset.firebaseDatasetID,
          firebaseUserUID: dataset.firebaseUserUID,
        })
        .return('Dataset')
        .run();
    }
    // annotations part

    // column part
    for (const column of dataset.columnData) {
      // Check if the Column node of this dataset already exists
      const existingColumn = await this.queryRepository
        .initQuery()
        .match([
          node('dataset:Dataset', 'Dataset', {
            firebaseDatasetID: dataset.firebaseDatasetID,
          }),
          relation('out', 'rel', 'HAS_COLUMN'),
          node('column:Column', 'Column', {
            columnName: column.columnName,
          }),
        ])
        .return('column')
        .run();

      if (existingColumn.length === 0) {
        // Create the Column node if it doesn't exist
        await this.queryRepository
          .initQuery()
          .match([
            node('dataset:Dataset', 'Dataset', {
              firebaseDatasetID: dataset.firebaseDatasetID,
            }),
          ])
          .create([
            node('dataset'),
            relation('out', 'rel', 'HAS_COLUMN'),
            node('column:Column', 'Column', {
              columnName: column.columnName,
              columnDescription: column.columnDescription,
            }),
          ])
          .return('column')
          .run();
      }
    }

    // annotations part --------------------------------
    const annotations = [];
    let prevAnnotationId;

    // Loop through the specified number of annotations
    for (let i = 0; i < numberOfAnnotations; i++) {
      const annotationId = uuidv4();
      const annotationName = `Annotation ${i}`;
      const createdAt = new Date().toISOString();
      const description = `Description ${i}`;
      const firebaseUserUID = 'xqcO5YrSc1gb6bf9rVF41Rwz30s2';
      const shortcut = `Shortcut ${i}`;

      // Create the annotation object
      const annotation = {
        id: annotationId,
        name: annotationName,
        createdAt,
        description,
        firebaseUserUID,
        shortcut,
      };

      annotations.push(annotation); // Store the annotation object

      // Execute Cypher query to create the annotation node
      await this.queryRepository.initQuery().raw`
        MERGE (annotation:Annotation { id: ${annotation.id} })
        ON CREATE SET annotation.name = ${annotation.name},
                      annotation.createdAt = ${annotation.createdAt},
                      annotation.description = ${annotation.description},
                      annotation.firebaseUserUID = ${annotation.firebaseUserUID},
                      annotation.shortcut = ${annotation.shortcut}
      `.run();

      // Create the RELATED_TO relationship between annotations
      if (prevAnnotationId) {
        await this.queryRepository.initQuery().raw`
          MATCH (source:Annotation { id: ${prevAnnotationId} }), (target:Annotation { id: ${annotation.id} })
          CREATE (source)-[:RELATED_TO]->(target)
        `.run();
      }

      // Break relationship after every fifth annotation
      if ((i + 1) % 5 === 0 && i > 0 && i < numberOfAnnotations - 1) {
        prevAnnotationId = null; // Reset prevAnnotationId
      } else {
        prevAnnotationId = annotation.id; // Update prevAnnotationId
      }

      // Assign annotation to a specific column
      const columnDataIndex = i % dataset.columnData.length; // Cycle through columnData
      const columnName = dataset.columnData[columnDataIndex].columnName;
      await this.queryRepository.initQuery().raw`
        MATCH (column:Column { columnName: ${columnName} })
        MATCH (annotation:Annotation { id: ${annotation.id} })
        MERGE (column)-[:ANNOTATED_WITH]->(annotation)
      `.run();
    }
    console.timeEnd('testing'); // End the timer
  }
}
