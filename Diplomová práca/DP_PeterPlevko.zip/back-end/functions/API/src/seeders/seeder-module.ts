import { Module } from '@nestjs/common';
import { SeederController } from './seeder-controller';
import { SeederService } from './seeder-service';
import { SeedNeo4j } from './seed-neo4j-service';
import { FirebaseModule } from 'src/firebase/firebase.module';
import { SeedPostgreSQL } from './seed-postgresql-service';
import { PostgreSQLModule } from 'src/postgresql/postgres.module';
import { Neo4jModule } from 'src/neo4j/neo4j.module';

@Module({
  imports: [
    FirebaseModule,
    Neo4jModule.forRootAsync(),
    PostgreSQLModule.forRootAsync(),
  ],
  controllers: [SeederController],
  providers: [SeederService, SeedNeo4j, SeedPostgreSQL],
})
export class SeederModule {}
