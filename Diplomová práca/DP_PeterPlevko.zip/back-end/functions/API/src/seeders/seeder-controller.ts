import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { SeederService } from './seeder-service';
import { UserGuard } from '../api/guards/user.guard';
@Controller()
export class SeederController {
  constructor(private readonly seederService: SeederService) {}

  @Get()
  getHello(): string {
    return 'Hello, world!';
  }

  @Get('/seedNeo4jDatabase')
  @UseGuards(UserGuard)
  async seedNeo4jDatabase(): Promise<string> {
    try {
      await this.seederService.seedNeo4jDatabase();
      return 'Database seeding initiated.';
    } catch (error) {
      return `Error during database seeding: ${error.message}`;
    }
  }

  @Get('/seedPostgreSQLDatabase')
  @UseGuards(UserGuard)
  async seedPostgreSQLDatabase(): Promise<string> {
    try {
      await this.seederService.seedPostgreSQLDatabase();
      return 'Database seeding initiated.';
    } catch (error) {
      return `Error during database seeding: ${error.message}`;
    }
  }

  @Get('/testingNeo4j/:numberOfAnnotations')
  @UseGuards(UserGuard)
  async testingNeo4j(
    @Param('numberOfAnnotations') numberOfAnnotations: number,
  ): Promise<any> {
    return await this.seederService.testingNeo4j(numberOfAnnotations);
  }

  @Get('/testingPostgreSQL/:numberOfAnnotations')
  @UseGuards(UserGuard)
  async testingPostgreSQL(
    @Param('numberOfAnnotations') numberOfAnnotations: number,
  ): Promise<any> {
    return await this.seederService.testingPostgreSQL(numberOfAnnotations);
  }
}
