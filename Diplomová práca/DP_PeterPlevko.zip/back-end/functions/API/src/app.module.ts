import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AnnotationModule } from './api/annotation/annotation.module';
import { DatasetModule } from './api/dataset/dataset.module';
import { ColumnModule } from './api/column/column.module';
import { SeederModule } from './seeders/seeder-module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' }),
    DatasetModule,
    ColumnModule,
    AnnotationModule,
    SeederModule,
  ],
  controllers: [AppController],
  providers: [],
})
export class AppModule {}
