import { Inject, Injectable } from '@nestjs/common';
import { PG_CONNECTION } from 'src/postgresql/postgres.constants';
import { UpdateOrCreateDTO } from './dto-and-response/update-or-create.dto';
import { UpdateOrCreateResponse } from './dto-and-response/update-or-create-response';
import { GetColumnsDescriptionsResponse } from './dto-and-response/get-column-descriptions-response';
import { ColumnService } from './column.service';

@Injectable()
export class ColumnServicePostgreSQL implements ColumnService {
  constructor(@Inject(PG_CONNECTION) private conn: any) {}

  async updateOrCreate(
    updateOrCreate: UpdateOrCreateDTO,
  ): Promise<UpdateOrCreateResponse[]> {
    const { firebaseDatasetID, columns } = updateOrCreate;

    const results: UpdateOrCreateResponse[] = [];

    // Check if the dataset exists
    const datasetExistsQuery = `
      SELECT id
      FROM dataset
      WHERE firebase_dataset_id = $1
    `;

    const datasetExistsResult = await this.conn.query(datasetExistsQuery, [
      firebaseDatasetID,
    ]);

    if (datasetExistsResult.rows.length === 0) {
      // Dataset does not exist, return null or handle accordingly
      return null;
    }

    // Start a transaction
    await this.conn.query('BEGIN');

    try {
      for (const { columnName, columnDescription } of columns) {
        // Try to update the column, if it exists
        const updateQuery = `
          WITH existing_column AS (
            SELECT id, column_description
            FROM dataset_column
            WHERE dataset_id = (
              SELECT id
              FROM dataset
              WHERE firebase_dataset_id = $1
            ) AND column_name = $2
            FOR UPDATE
          )
          UPDATE dataset_column
          SET column_description = $3
          FROM existing_column
          WHERE dataset_column.id = existing_column.id
          RETURNING dataset_column.column_name, dataset_column.column_description;
        `;

        const updateResult = await this.conn.query(updateQuery, [
          firebaseDatasetID,
          columnName,
          columnDescription,
        ]);

        if (updateResult.rows.length > 0) {
          results.push(updateResult.rows[0]);
        } else {
          // If no rows were updated, insert a new column
          const insertQuery = `
            INSERT INTO dataset_column (dataset_id, column_name, column_description)
            VALUES (
              (SELECT id FROM dataset WHERE firebase_dataset_id = $1),
              $2,
              $3
            )
            RETURNING dataset_column.column_name, dataset_column.column_description;
          `;

          const insertResult = await this.conn.query(insertQuery, [
            firebaseDatasetID,
            columnName,
            columnDescription,
          ]);

          if (insertResult.rows.length > 0) {
            results.push(insertResult.rows[0]);
          }
        }
      }

      // Commit the transaction
      await this.conn.query('COMMIT');
      return results;
    } catch (error) {
      // Rollback the transaction in case of an error
      await this.conn.query('ROLLBACK');
      console.error(error);
      return null;
    }
  }

  async getColumnsDescriptions(
    datasetId: string,
  ): Promise<GetColumnsDescriptionsResponse[] | null> {
    const query = `
      SELECT column_name AS "columnName", column_description AS "columnDescription"
      FROM dataset_column
      WHERE dataset_id = (
        SELECT id
        FROM dataset
        WHERE firebase_dataset_id = $1
      );
    `;

    const result = await this.conn.query(query, [datasetId]);

    if (result.rows.length > 0) {
      const columns = result.rows.map((row) => ({
        columnName: row.columnName,
        columnDescription: row.columnDescription,
      }));
      return columns;
    } else {
      return [];
    }
  }
}
