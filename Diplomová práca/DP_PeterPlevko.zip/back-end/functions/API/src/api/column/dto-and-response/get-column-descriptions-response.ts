import { IsNotEmpty } from 'class-validator';

export class GetColumnsDescriptionsResponse {
  @IsNotEmpty()
  datasetId: string;

  @IsNotEmpty()
  columnName: string;
}
