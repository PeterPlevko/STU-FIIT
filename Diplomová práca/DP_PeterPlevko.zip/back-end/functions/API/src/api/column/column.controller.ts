import { Body, Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import { ColumnService } from './column.service';
import { GetColumnsDescriptionsResponse } from './dto-and-response/get-column-descriptions-response';
import { UpdateOrCreateDTO } from './dto-and-response/update-or-create.dto';
import { UpdateOrCreateResponse } from './dto-and-response/update-or-create-response';
import { UserGuard } from '../guards/user.guard';

@Controller('column')
export class ColumnController {
  constructor(private readonly columnService: ColumnService) {}

  @Get('/getColumnsDescriptions')
  async getColumnsDescriptions(
    @Query('datasetId') datasetId: string,
  ): Promise<GetColumnsDescriptionsResponse[] | null> {
    const decodedDatasetId = decodeURIComponent(datasetId);

    // You can now use encodedName and datasetName in your method
    return await this.columnService.getColumnsDescriptions(decodedDatasetId);
  }

  @Post('/updateOrCreate')
  @UseGuards(UserGuard)
  async annotateColumn(
    @Body() updateOrCreate: UpdateOrCreateDTO,
  ): Promise<UpdateOrCreateResponse[]> {
    return await this.columnService.updateOrCreate(updateOrCreate);
  }
}
