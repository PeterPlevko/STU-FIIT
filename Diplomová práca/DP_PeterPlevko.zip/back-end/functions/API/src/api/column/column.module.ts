// annotation.module.ts
import { Module, Provider } from '@nestjs/common';
import { ColumnController } from './column.controller';
import { ColumnService } from './column.service';
import { ColumnServiceNeo4j } from './column.service.neo4j';
import { ColumnServicePostgreSQL } from './column.service.postgresql';
import { QueryRepository } from 'src/neo4j/query.repository';
import { Neo4jModule } from 'src/neo4j/neo4j.module';
import { PostgreSQLModule } from 'src/postgresql/postgres.module';
import { PG_CONNECTION } from 'src/postgresql/postgres.constants';

const columnServiceProvider: Provider = {
  provide: ColumnService,
  useFactory: async (
    queryRepository: QueryRepository,
    postgresConnection: any, // Inject the PostgreSQL connection
  ) => {
    if (process.env.DB_TYPE === 'neo4j') {
      return new ColumnServiceNeo4j(queryRepository);
    } else {
      return new ColumnServicePostgreSQL(postgresConnection); // Pass the postgresConnection as an argument
    }
  },
  inject: [QueryRepository, PG_CONNECTION], // Inject the PostgreSQL connection
};

@Module({
  imports: [Neo4jModule.forRootAsync(), PostgreSQLModule.forRootAsync()],
  controllers: [ColumnController],
  providers: [columnServiceProvider],
})
export class ColumnModule {
  constructor() {}
}
