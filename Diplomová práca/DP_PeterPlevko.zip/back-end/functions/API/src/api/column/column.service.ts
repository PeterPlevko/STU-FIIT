import { Injectable } from '@nestjs/common';
import { GetColumnsDescriptionsResponse } from './dto-and-response/get-column-descriptions-response';
import { UpdateOrCreateDTO } from './dto-and-response/update-or-create.dto';
import { UpdateOrCreateResponse } from './dto-and-response/update-or-create-response';

@Injectable()
export abstract class ColumnService {
  // getColumnDescription
  abstract getColumnsDescriptions(
    datasetId: string,
  ): Promise<GetColumnsDescriptionsResponse[] | null>;

  abstract updateOrCreate(
    updateOrCreate: UpdateOrCreateDTO,
  ): Promise<UpdateOrCreateResponse[]>;
}
