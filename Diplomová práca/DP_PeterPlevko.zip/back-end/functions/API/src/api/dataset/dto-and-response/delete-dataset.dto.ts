import { IsNotEmpty } from 'class-validator';

export class DeleteDatasetsDto {
  @IsNotEmpty()
  id: string;

  @IsNotEmpty()
  authorName: string;

  @IsNotEmpty()
  publishDate: string;

  @IsNotEmpty()
  datasetName: string;

  @IsNotEmpty()
  authorUID: string;

  @IsNotEmpty()
  csvFileUrl: string;

  @IsNotEmpty()
  size: string;
}
