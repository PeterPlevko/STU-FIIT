// annotation.module.ts
import { Module, Provider } from '@nestjs/common';
import { DatasetController } from './dataset.controller';
import { DatasetService } from './dataset.service';
import { DatasetServiceNeo4j } from './dataset.service.neo4j';
import { DatasetServicePostgresql } from './dataset.service.postgresql';
import { QueryRepository } from 'src/neo4j/query.repository';
import { Neo4jModule } from 'src/neo4j/neo4j.module';
import { PostgreSQLModule } from 'src/postgresql/postgres.module';
import { PG_CONNECTION } from 'src/postgresql/postgres.constants';

const datasetServiceProvider: Provider = {
  provide: DatasetService,
  useFactory: async (
    queryRepository: QueryRepository,
    postgresConnection: any, // Inject the PostgreSQL connection
  ) => {
    if (process.env.DB_TYPE === 'neo4j') {
      return new DatasetServiceNeo4j(queryRepository);
    } else {
      return new DatasetServicePostgresql(postgresConnection); // Pass the postgresConnection as an argument
    }
  },
  inject: [QueryRepository, PG_CONNECTION], // Inject the PostgreSQL connection
};

@Module({
  imports: [Neo4jModule.forRootAsync(), PostgreSQLModule.forRootAsync()],
  controllers: [DatasetController],
  providers: [datasetServiceProvider],
})
export class DatasetModule {}
