import { IsNotEmpty } from 'class-validator';

export class UpdateDatasetDescriptionDTO {
  datasetDescription: string;

  @IsNotEmpty()
  id: string;
}
