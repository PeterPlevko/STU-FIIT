import { Inject, Injectable } from '@nestjs/common';
import { CreateDatasetDto } from './dto-and-response/create-dataset.dto';
import { CreateDatasetResponse } from './dto-and-response/create-dataset-response';
import { UpdateDatasetDescriptionDTO } from './dto-and-response/update-dataset-description.dto';
import { DeleteDatasetsDto } from './dto-and-response/delete-dataset.dto';
import { PG_CONNECTION } from 'src/postgresql/postgres.constants';
import { DatasetService } from './dataset.service';
import { RenameDatasetDTO } from './dto-and-response/rename-dataset.dto';

@Injectable()
export class DatasetServicePostgresql implements DatasetService {
  constructor(@Inject(PG_CONNECTION) private conn: any) {}

  async createDataset(
    createDatasetDto: CreateDatasetDto,
  ): Promise<CreateDatasetResponse | null> {
    const { firebaseUserUID, firebaseDatasetID, datasetName } =
      createDatasetDto;

    try {
      const result = await this.conn.query(
        'INSERT INTO dataset (firebase_user_uid, firebase_dataset_id, dataset_name) VALUES ($1, $2, $3) RETURNING id, firebase_user_uid, firebase_dataset_id, dataset_name;',
        [firebaseUserUID, firebaseDatasetID, datasetName],
      );

      if (result.rows.length > 0) {
        const { id, firebase_user_uid, firebase_dataset_id, dataset_name } =
          result.rows[0];
        return {
          id,
          firebaseUserUID: firebase_user_uid,
          firebaseDatasetID: firebase_dataset_id,
          datasetName: dataset_name,
        };
      }

      return null;
    } catch (error) {
      // Handle the error
      console.error(error);
      return null;
    }
  }

  async getDatasetDescription(datasetId: string): Promise<string> {
    try {
      const result = await this.conn.query(
        'SELECT dataset_description FROM dataset WHERE firebase_dataset_id = $1;',
        [datasetId],
      );

      if (result.rows.length > 0) {
        return result.rows[0].dataset_description || '';
      } else {
        return '';
      }
    } catch (error) {
      // Handle the error
      console.error(error);
      return '';
    }
  }

  async updateDatasetDescription(
    updateDatasetDescription: UpdateDatasetDescriptionDTO,
  ): Promise<string> {
    try {
      const { datasetDescription, id } = updateDatasetDescription;

      const result = await this.conn.query(
        'UPDATE dataset SET dataset_description = $1 WHERE firebase_dataset_id = $2 RETURNING dataset_description;',
        [datasetDescription, id],
      );

      if (result.rows.length > 0) {
        return result.rows[0].dataset_description || '';
      } else {
        // If no rows were updated, the dataset ID might not exist
        return 'Dataset not found';
      }
    } catch (error) {
      // Handle the error
      console.error(error);
      return 'Error updating dataset description';
    }
  }

  async deleteDatasets(
    datasetsToDelete: DeleteDatasetsDto[],
  ): Promise<boolean[]> {
    const deletionResults = await Promise.all(
      datasetsToDelete.map(async (dataset: any) => {
        try {
          // Start a transaction
          await this.conn.query('BEGIN');

          // Delete rows from column_annotation table that reference dataset_column rows
          const deleteColumnAnnotationQuery = `
            DELETE FROM column_annotation
            WHERE column_id IN (
              SELECT id
              FROM dataset_column
              WHERE dataset_id = (
                SELECT id
                FROM dataset
                WHERE firebase_dataset_id = $1
              )
            )
          `;
          await this.conn.query(deleteColumnAnnotationQuery, [dataset.id]);

          // Delete columns associated with the dataset
          const deleteColumnsQuery = `
            DELETE FROM dataset_column
            WHERE dataset_id = (
              SELECT id
              FROM dataset
              WHERE firebase_dataset_id = $1
            )
          `;
          await this.conn.query(deleteColumnsQuery, [dataset.id]);

          // Delete the dataset
          const deleteDatasetQuery = `
            DELETE FROM dataset
            WHERE firebase_dataset_id = $1
            RETURNING 1 as deletedCount
          `;
          const result = await this.conn.query(deleteDatasetQuery, [
            dataset.id,
          ]);

          // Commit the transaction
          await this.conn.query('COMMIT');

          return result.rows[0]?.deletedcount > 0;
        } catch (error) {
          // Rollback the transaction in case of an error
          await this.conn.query('ROLLBACK');
          console.error(error);
          return false;
        }
      }),
    );

    return deletionResults;
  }

  async renameDataset(renameDataset: RenameDatasetDTO): Promise<any> {
    const { datasetName, firebaseDatasetID } = renameDataset;

    try {
      const result = await this.conn.query(
        'UPDATE dataset SET dataset_name = $1 WHERE firebase_dataset_id = $2 RETURNING dataset_name;',
        [datasetName, firebaseDatasetID],
      );

      if (result.rows.length > 0) {
        return result.rows[0].dataset_name || '';
      } else {
        // If no rows were updated, the dataset ID might not exist
        return 'Dataset not found';
      }
    } catch (error) {
      // Handle the error
      console.error(error);
      return 'Error renaming dataset';
    }
  }
}
