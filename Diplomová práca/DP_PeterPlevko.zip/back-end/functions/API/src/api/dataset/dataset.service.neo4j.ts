import { Injectable } from '@nestjs/common';
import { QueryRepository } from 'src/neo4j/query.repository';
import { CreateDatasetDto } from './dto-and-response/create-dataset.dto';
import { CreateDatasetResponse } from './dto-and-response/create-dataset-response';
import { UpdateDatasetDescriptionDTO } from './dto-and-response/update-dataset-description.dto';
import { DeleteDatasetsDto } from './dto-and-response/delete-dataset.dto';
import { DatasetService } from './dataset.service';
import { RenameDatasetDTO } from './dto-and-response/rename-dataset.dto';

@Injectable()
export class DatasetServiceNeo4j implements DatasetService {
  constructor(private readonly queryRepository: QueryRepository) {}

  async createDataset(
    createDatasetDto: CreateDatasetDto,
  ): Promise<CreateDatasetResponse | null> {
    const { firebaseUserUID, firebaseDatasetID, datasetName } =
      createDatasetDto;

    const result = await this.queryRepository
      .initQuery()
      .createNode('Dataset', 'Dataset', {
        firebaseUserUID: firebaseUserUID,
        firebaseDatasetID: firebaseDatasetID,
        datasetName: datasetName,
      })
      .return('ID(Dataset) as id, properties(Dataset) as properties')
      .run();

    if (result.length > 0) {
      const { id, properties } = result[0];
      return { id, ...properties };
    }

    return null;
  }

  async getDatasetDescription(datasetId: string): Promise<string> {
    const result = await this.queryRepository
      .initQuery()
      .matchNode('Dataset', 'Dataset', {
        firebaseDatasetID: datasetId,
      })
      .return('ID(Dataset) as id, properties(Dataset) as properties')
      .run();

    if (result[0]) {
      return result[0].properties.datasetDescription;
    } else {
      return '';
    }
  }

  async updateDatasetDescription(
    updateDatasetDescription: UpdateDatasetDescriptionDTO,
  ): Promise<string> {
    const { datasetDescription, id } = updateDatasetDescription;

    // Check if the dataset exists
    const checkQuery = `
      MATCH (d:Dataset {firebaseDatasetID: $id})
      RETURN COUNT(d) AS datasetCount
    `;

    const checkResult = await this.queryRepository
      .initQuery()
      .raw(checkQuery, { id })
      .run();

    if (checkResult[0].datasetCount === 0) {
      return 'Dataset does not exist';
    }

    // Update the dataset description
    const result = await this.queryRepository
      .initQuery()
      .matchNode('Dataset', 'Dataset', {
        firebaseDatasetID: id,
      })
      .setValues({ 'Dataset.datasetDescription': datasetDescription })
      .return('ID(Dataset) as id, properties(Dataset) as properties')
      .run();

    return result[0].properties.datasetDescription;
  }

  async deleteDatasets(
    datasetsToDelete: DeleteDatasetsDto[],
  ): Promise<boolean[]> {
    const deletionResults = await Promise.all(
      datasetsToDelete.map(async (dataset: any) => {
        const query = `
          MATCH (dataset:Dataset {firebaseDatasetID: $id})
          OPTIONAL MATCH (dataset)-[r:HAS_COLUMN]->(column:Column)
          DETACH DELETE dataset, column, r
          RETURN COUNT(dataset) as deletedCount
        `;

        const result = await this.queryRepository
          .initQuery()
          .raw(query, { id: dataset.id })
          .run();

        return result[0]?.deletedCount > 0;
      }),
    );

    return deletionResults;
  }

  async renameDataset(renameDataset: RenameDatasetDTO): Promise<string> {
    const { datasetName, firebaseDatasetID } = renameDataset;

    // Check if the dataset exists
    const checkQuery = `
      MATCH (d:Dataset {firebaseDatasetID: $id})
      RETURN COUNT(d) AS datasetCount
    `;

    const checkResult = await this.queryRepository
      .initQuery()
      .raw(checkQuery, { id: firebaseDatasetID })
      .run();

    if (checkResult[0].datasetCount === 0) {
      return 'Dataset does not exist';
    }

    // Rename the dataset
    const result = await this.queryRepository
      .initQuery()
      .matchNode('Dataset', 'Dataset', {
        firebaseDatasetID: firebaseDatasetID,
      })
      .setValues({ 'Dataset.datasetName': datasetName })
      .return('ID(Dataset) as id, properties(Dataset) as properties')
      .run();

    return result[0].properties.datasetName;
  }
}
