import { Body, Controller, Post, Get, Param, UseGuards } from '@nestjs/common';
import { DatasetService } from './dataset.service';
import { CreateDatasetDto } from './dto-and-response/create-dataset.dto';
import { CreateDatasetResponse } from './dto-and-response/create-dataset-response';
import { UpdateDatasetDescriptionDTO } from './dto-and-response/update-dataset-description.dto';
import { UserGuard } from '../guards/user.guard';
import { DeleteDatasetsDto } from './dto-and-response/delete-dataset.dto';
import { RenameDatasetDTO } from './dto-and-response/rename-dataset.dto';

@Controller('dataset')
export class DatasetController {
  constructor(private readonly datasetService: DatasetService) {}

  @Post('/createDataset')
  @UseGuards(UserGuard)
  async createDataset(
    @Body() createDatasetDto: CreateDatasetDto,
  ): Promise<CreateDatasetResponse | null> {
    return await this.datasetService.createDataset(createDatasetDto);
  }

  @Post('/deleteDatasets')
  @UseGuards(UserGuard)
  async deleteDatasets(
    @Body() deleteDatasetsDto: DeleteDatasetsDto[],
  ): Promise<boolean[] | null> {
    return await this.datasetService.deleteDatasets(deleteDatasetsDto);
  }

  @Get('/getDatasetDescription/:datasetId')
  async getDatasetDescription(
    @Param('datasetId') datasetId: string,
  ): Promise<string> {
    return await this.datasetService.getDatasetDescription(datasetId);
  }

  @Post('/updateDatasetDescription')
  @UseGuards(UserGuard)
  async updateDatasetDescription(
    @Body() updateDatasetDescription: UpdateDatasetDescriptionDTO,
  ): Promise<any> {
    return await this.datasetService.updateDatasetDescription(
      updateDatasetDescription,
    );
  }

  @Post('/renameDataset')
  @UseGuards(UserGuard)
  async renameDataset(@Body() renameDataset: RenameDatasetDTO): Promise<any> {
    return await this.datasetService.renameDataset(renameDataset);
  }
}
