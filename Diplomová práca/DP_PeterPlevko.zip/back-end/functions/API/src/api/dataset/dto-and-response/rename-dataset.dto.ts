import { IsNotEmpty } from 'class-validator';

export class RenameDatasetDTO {
  @IsNotEmpty()
  datasetName: string;

  @IsNotEmpty()
  firebaseDatasetID: string;
}
