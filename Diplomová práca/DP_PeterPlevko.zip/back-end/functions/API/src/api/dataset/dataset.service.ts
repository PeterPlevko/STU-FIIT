import { Injectable } from '@nestjs/common';
import { CreateDatasetDto } from './dto-and-response/create-dataset.dto';
import { CreateDatasetResponse } from './dto-and-response/create-dataset-response';
import { UpdateDatasetDescriptionDTO } from './dto-and-response/update-dataset-description.dto';
import { DeleteDatasetsDto } from './dto-and-response/delete-dataset.dto';
import { RenameDatasetDTO } from './dto-and-response/rename-dataset.dto';

@Injectable()
export abstract class DatasetService {
  abstract createDataset(
    createDatasetDto: CreateDatasetDto,
  ): Promise<CreateDatasetResponse | null>;

  abstract getDatasetDescription(datasetId: string): Promise<string>;

  abstract updateDatasetDescription(
    updateDatasetDescription: UpdateDatasetDescriptionDTO,
  ): Promise<string>;

  abstract deleteDatasets(
    datasetsToDelete: DeleteDatasetsDto[],
  ): Promise<boolean[]>;

  abstract renameDataset(renameDataset: RenameDatasetDTO): Promise<string>;
}
