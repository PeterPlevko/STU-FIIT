// postgres.module.ts
import { Module, DynamicModule } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { Pool } from 'pg';

export const PG_CONNECTION = 'PG_CONNECTION';

@Module({
  imports: [ConfigModule.forRoot()],
  providers: [
    {
      provide: PG_CONNECTION,
      useFactory: async (configService: ConfigService) => {
        const pool = new Pool({
          user: configService.get<string>('DB_POSTGRES_USERNAME'),
          host: configService.get<string>('DB_POSTGRES_HOST'),
          database: configService.get<string>('DB_POSTGRES_NAME'),
          password: configService.get<string>('DB_POSTGRES_PASSWORD'),
          port: configService.get<number>('DB_POSTGRES_PORT', 5432), // default to 5432 if not provided
        });

        // Check and create tables if they don't exist
        await checkAndCreateTables(pool);

        return pool;
      },
      inject: [ConfigService],
    },
  ],
  exports: [PG_CONNECTION],
})
export class PostgreSQLModule {
  static forRootAsync(): DynamicModule {
    return {
      module: PostgreSQLModule,
      imports: [ConfigModule.forRoot()],
      exports: [PG_CONNECTION],
    };
  }
}

async function checkAndCreateTables(pool: Pool): Promise<void> {
  const client = await pool.connect();
  try {
    // Create the uuid-ossp extension if it doesn't exist
    await client.query('CREATE EXTENSION IF NOT EXISTS "uuid-ossp";');

    // Create tables
    await createDatasetTable(pool);
    await createDatasetColumnTable(pool);
    await createAnnotationTable(pool);
    await createColumnAnnotationTable(pool);
    await createRelationships(pool);
    // Add other tables and relationships as needed
  } finally {
    client.release();
  }
}

async function createDatasetTable(pool: Pool): Promise<void> {
  const client = await pool.connect();
  try {
    const result = await client.query(
      "SELECT table_name FROM information_schema.tables WHERE table_name = 'dataset'",
    );
    if (result.rows.length === 0) {
      await client.query(`
        CREATE TABLE dataset (
          id SERIAL PRIMARY KEY,
          dataset_name VARCHAR(255),
          dataset_description TEXT,
          firebase_dataset_id VARCHAR(255),
          firebase_user_uid VARCHAR(255)
        );
      `);
      console.log('Table "dataset" created.');
    } else {
      console.log('Table "dataset" already exists.');
    }
  } finally {
    client.release();
  }
}

async function createDatasetColumnTable(pool: Pool): Promise<void> {
  const client = await pool.connect();
  try {
    const result = await client.query(
      "SELECT table_name FROM information_schema.tables WHERE table_name = 'dataset_column';",
    );
    if (result.rows.length === 0) {
      await client.query(`
        CREATE TABLE dataset_column (
          id SERIAL PRIMARY KEY,
          column_name VARCHAR(255),
          column_description TEXT
        );
      `);
      console.log('Table "dataset_column" created.');
    } else {
      console.log('Table "dataset_column" already exists.');
    }
  } finally {
    client.release();
  }
}

async function createAnnotationTable(pool: Pool): Promise<void> {
  const client = await pool.connect();
  try {
    const result = await client.query(
      "SELECT table_name FROM information_schema.tables WHERE table_name = 'annotation'",
    );
    if (result.rows.length === 0) {
      await client.query(`
      CREATE TABLE annotation (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        name VARCHAR(255),
        description TEXT,
        created_at TIMESTAMP,
        firebase_user_uid VARCHAR(255),
        shortcut VARCHAR(255),
        parent_annotation_id UUID REFERENCES annotation(id) ON DELETE CASCADE
      );
      `);
      console.log('Table "annotation" created.');
    } else {
      console.log('Table "annotation" already exists.');
    }
  } finally {
    client.release();
  }
}

// Add this function to create the column_annotation table
async function createColumnAnnotationTable(pool: Pool): Promise<void> {
  const client = await pool.connect();
  try {
    const result = await client.query(
      "SELECT table_name FROM information_schema.tables WHERE table_name = 'column_annotation';",
    );
    if (result.rows.length === 0) {
      await client.query(`
        CREATE TABLE column_annotation (
          column_id INT REFERENCES dataset_column(id),
          annotation_id UUID REFERENCES annotation(id),
          PRIMARY KEY (column_id, annotation_id)
        );
      `);
      console.log('Table "column_annotation" created.');
    } else {
      console.log('Table "column_annotation" already exists.');
    }
  } finally {
    client.release();
  }
}

async function createRelationships(pool: Pool): Promise<void> {
  await createColumnRelationship(pool);
}

async function createColumnRelationship(pool: Pool): Promise<void> {
  const client = await pool.connect();
  try {
    const result = await client.query(
      "SELECT column_name FROM information_schema.columns WHERE table_name = 'dataset_column' AND column_name = 'dataset_id';",
    );
    if (result.rows.length === 0) {
      await client.query(`
        ALTER TABLE dataset_column
        ADD COLUMN dataset_id INT REFERENCES dataset(id);
      `);
      console.log('Relationship added for dataset_column to dataset.');
    } else {
      console.log('Relationship for dataset_column to dataset already exists.');
    }
  } finally {
    client.release();
  }
}
