// postgres.constants.ts
export const PG_CONNECTION = 'PG_CONNECTION';
