// firestoreDataset
const serviceAccountKey = {
  
};
export default serviceAccountKey;
