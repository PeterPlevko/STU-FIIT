import { Module } from '@nestjs/common';
import { FirebaseService } from './fire-base.service';

@Module({
  imports: [],
  exports: [FirebaseService],
  controllers: [],
  providers: [FirebaseService],
})
export class FirebaseModule {}
