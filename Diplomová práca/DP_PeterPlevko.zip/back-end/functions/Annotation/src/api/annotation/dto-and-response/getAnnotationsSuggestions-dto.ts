import { IsNotEmpty, IsArray } from 'class-validator';

export class GetAnnotationsSuggestionsDTO {
  @IsNotEmpty()
  id: string;

  @IsNotEmpty()
  @IsArray()
  columnsForAnnotationsSuggestionsArray: string[];
}
