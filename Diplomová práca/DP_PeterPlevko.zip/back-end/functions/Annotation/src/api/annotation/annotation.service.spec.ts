import { Test, TestingModule } from '@nestjs/testing';
import { AnnotationServiceNeo4j } from './annotation.service.neo4j';

describe('AnnotationService', () => {
  let service: AnnotationServiceNeo4j;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AnnotationServiceNeo4j],
    }).compile();

    service = module.get<AnnotationServiceNeo4j>(AnnotationServiceNeo4j);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
