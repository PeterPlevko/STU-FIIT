import { IsNotEmpty, IsString } from 'class-validator';

class ColumnDTO {
  @IsNotEmpty()
  @IsString()
  columnDescription: string;

  @IsNotEmpty()
  @IsString()
  columnName: string;
}

class AnnotationDTO {
  @IsNotEmpty()
  @IsString()
  createdAt: string;

  @IsNotEmpty()
  @IsString()
  shortcut: string;

  @IsNotEmpty()
  @IsString()
  firebaseUserUID: string;

  @IsNotEmpty()
  @IsString()
  name: string;

  @IsNotEmpty()
  @IsString()
  description: string;

  @IsNotEmpty()
  @IsString()
  id: string;
}

export class GetColumnsAnnotationsResponse {
  @IsNotEmpty()
  column: ColumnDTO;

  @IsNotEmpty()
  annotations: AnnotationDTO[];
}
