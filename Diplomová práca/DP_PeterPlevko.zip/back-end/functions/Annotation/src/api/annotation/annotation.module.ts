// annotation.module.ts
import { Module, Provider } from '@nestjs/common';
import { AnnotationController } from './annotation.controller';
import { AnnotationService } from './annotation.service';
import { AnnotationServiceNeo4j } from './annotation.service.neo4j';
import { AnnotationServicePostgreSQL } from './annotation.service.postgresql';
import { QueryRepository } from 'src/neo4j/query.repository';
import { Neo4jModule } from 'src/neo4j/neo4j.module';
import { PostgreSQLModule } from 'src/postgresql/postgres.module';
import { PG_CONNECTION } from 'src/postgresql/postgres.constants';
import { FirebaseModule } from '../../firebase/firebase.module';
import { FirebaseService } from 'src/firebase/fire-base.service';

const annotationServiceProvider: Provider = {
  provide: AnnotationService,
  useFactory: async (
    queryRepository: QueryRepository,
    postgresConnection: any, // Inject the PostgreSQL connection
    firebaseService: FirebaseService, // Inject the FirebaseService
  ) => {
    if (process.env.DB_TYPE === 'neo4j') {
      return new AnnotationServiceNeo4j(queryRepository, firebaseService);
    } else {
      return new AnnotationServicePostgreSQL(
        postgresConnection,
        firebaseService,
      ); // Pass the postgresConnection as an argument
    }
  },
  inject: [QueryRepository, PG_CONNECTION, FirebaseService], // Inject the PostgreSQL connection
};

@Module({
  imports: [
    Neo4jModule.forRootAsync(),
    PostgreSQLModule.forRootAsync(),
    FirebaseModule,
  ],
  controllers: [AnnotationController],
  providers: [annotationServiceProvider],
})
export class AnnotationModule {
  constructor() {}
}
