import {
  IsArray,
  IsNotEmpty,
  IsOptional,
  ValidateNested,
} from 'class-validator';

class AnnotationDto {
  @IsNotEmpty()
  createdAt: string;

  @IsNotEmpty()
  shortcut: string;

  @IsNotEmpty()
  firebaseUserUID: string;

  @IsNotEmpty()
  name: string;

  @IsNotEmpty()
  description: string;

  @IsNotEmpty()
  id: string;

  @IsNotEmpty()
  count: number;
}

export class GetAnnotationsSuggestionsResponse {
  @IsNotEmpty()
  columnName?: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  annotations?: AnnotationDto[];
}
