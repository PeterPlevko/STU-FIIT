import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
  Request,
} from '@nestjs/common';
import { AnnotationService } from './annotation.service';
import { CreateAnnotationDto } from './dto-and-response/create-annotation.dto';
import { CreateAnnotationResponse } from './dto-and-response/create-annotation-response';
import { GetAnnotationsResponse } from './dto-and-response/get-annotations-response';
import { AnnotateColumnDto } from './dto-and-response/annotate-column-dto';
import { GetExportResponse } from './dto-and-response/get-export-response';
import { ConnectAnnotationsDto } from './dto-and-response/connect-annotations-dto';
import { GetColumnsAnnotationsResponse } from './dto-and-response/get-columns-annotations-response';
import { UserGuard } from '../guards/user.guard';
import { GetAnnotationsSuggestionsDTO } from './dto-and-response/getAnnotationsSuggestions-dto';
import { GetAnnotationsSuggestionsResponse } from './dto-and-response/getAnnotationsSuggestions-response';
import { UseGuards } from '@nestjs/common/decorators/core/use-guards.decorator';
import { FileInterceptor } from './fileInterceptor';
@Controller('annotation')
export class AnnotationController {
  constructor(private readonly annotationService: AnnotationService) {}

  @Post('/createAnnotation')
  @UseGuards(UserGuard)
  async createAnnotation(
    @Body() createAnnotationDto: CreateAnnotationDto,
  ): Promise<CreateAnnotationResponse> {
    return await this.annotationService.createAnnotation(createAnnotationDto);
  }

  @Get('/getAnnotations')
  async getAnnotations(): Promise<GetAnnotationsResponse[]> {
    return await this.annotationService.getAnnotations();
  }

  @Post('/annotateColumn')
  @UseGuards(UserGuard)
  async annotateColumn(
    @Body() annotateColumnDto: AnnotateColumnDto,
  ): Promise<boolean[]> {
    return await this.annotationService.annotateColumn(annotateColumnDto);
  }

  @Get('/getExport/:id')
  async getExport(@Param('id') id: string): Promise<GetExportResponse> {
    return await this.annotationService.getExport(id);
  }

  @Delete('/deleteAnnotation/:id')
  @UseGuards(UserGuard)
  async deleteAnnotation(@Param('id') id: string): Promise<string> {
    return await this.annotationService.deleteAnnotation(id);
  }

  @Post('/connectAnnotations')
  @UseGuards(UserGuard)
  async connectAnnotation(
    @Body() connectAnnotationsDto: ConnectAnnotationsDto,
  ): Promise<string> {
    return await this.annotationService.connectAnnotation(
      connectAnnotationsDto,
    );
  }

  @Get('/getColumnsAnnotations')
  async getColumnAnnotations(
    @Query('datasetId') datasetId: string,
  ): Promise<GetColumnsAnnotationsResponse[]> {
    const decodedDatasetId = decodeURIComponent(datasetId);
    return await this.annotationService.getColumnsAnnotations(decodedDatasetId);
  }

  @Post('/getAnnotationsSuggestions')
  @UseGuards(UserGuard)
  async getAnnotationsSuggestions(
    @Body() getAnnotationsSuggestionsDTO: GetAnnotationsSuggestionsDTO,
  ): Promise<GetAnnotationsSuggestionsResponse[]> {
    return await this.annotationService.getAnnotationsSuggestions(
      getAnnotationsSuggestionsDTO,
    );
  }

  // import
  @Post('/postImport')
  @UseGuards(UserGuard)
  @UseInterceptors(
    new FileInterceptor(2, {
      limits: {
        // limit to 100Mb
        fileSize: 1024 * 1024 * 100,
      },
    }),
  )
  async uploadFile(
    @UploadedFiles()
    files: {
      files: Express.Multer.File[];
    },
    @Request() req: Request,
  ) {
    // throw new NotImplementedException();
    const authorizationToken = req.headers['authorization'];

    const csvFile = files[0]; // Extract the first file under the key 'csvFile'
    const jsonFile = files[1]; // Extract the first file under the key 'jsonFile'
    const result = await this.annotationService.postImport(
      csvFile,
      jsonFile,
      authorizationToken,
    );
    return result;
  }
}
