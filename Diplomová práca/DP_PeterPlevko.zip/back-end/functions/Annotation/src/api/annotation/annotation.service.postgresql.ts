import { Inject, Injectable } from '@nestjs/common';
import { CreateAnnotationDto } from './dto-and-response/create-annotation.dto';
import { CreateAnnotationResponse } from './dto-and-response/create-annotation-response';
import { GetAnnotationsResponse } from './dto-and-response/get-annotations-response';
import { v4 as uuidv4 } from 'uuid';
import { AnnotateColumnDto } from './dto-and-response/annotate-column-dto';
import { GetExportResponse } from './dto-and-response/get-export-response';
import { ConnectAnnotationsDto } from './dto-and-response/connect-annotations-dto';
import { GetColumnsAnnotationsResponse } from './dto-and-response/get-columns-annotations-response';
import { GetAnnotationsSuggestionsDTO } from './dto-and-response/getAnnotationsSuggestions-dto';
import { GetAnnotationsSuggestionsResponse } from './dto-and-response/getAnnotationsSuggestions-response';
import { PG_CONNECTION } from 'src/postgresql/postgres.constants';
import { AnnotationService } from './annotation.service';
import { FirebaseService } from 'src/firebase/fire-base.service';
import { getAuth } from 'firebase-admin/auth';

const SMALL_FILE_SIZE_THRESHOLD = 1000000; // 1 MB
const MEDIUM_FILE_SIZE_THRESHOLD = 5000000; // 5 MB

interface UploadedFile {
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  buffer: Buffer;
  size: number;
}

@Injectable()
export class AnnotationServicePostgreSQL implements AnnotationService {
  constructor(
    @Inject(PG_CONNECTION) private conn: any,
    private readonly firebaseService: FirebaseService,
  ) {}

  async createAnnotation(
    createAnnotationDto: CreateAnnotationDto,
  ): Promise<CreateAnnotationResponse> {
    const {
      firebaseUserUID,
      name,
      description,
      createdAt,
      shortcut,
      relatedTo,
    } = createAnnotationDto;

    // Check if the related annotation exists
    const checkRelatedQuery = `
      SELECT 1
      FROM annotation
      WHERE id = $1
    `;

    const checkRelatedResult = await this.conn.query(checkRelatedQuery, [
      relatedTo,
    ]);

    const parentAnnotationId =
      checkRelatedResult.rows.length > 0 ? relatedTo : null;

    const uniqueId = uuidv4();

    // Convert createdAt to a Date object
    const createdAtDate = new Date(createdAt);

    // Insert new annotation
    const insertQuery = `
      INSERT INTO annotation (id, name, description, created_at, firebase_user_uid, shortcut, parent_annotation_id)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *;
    `;

    const values = [
      uniqueId,
      name,
      description,
      createdAtDate,
      firebaseUserUID,
      shortcut,
      parentAnnotationId,
    ];

    const createResult = await this.conn.query(insertQuery, values);
    const newAnnotation = createResult.rows[0];

    // Fetch the annotation and its related annotations
    const annotationResult = await this.conn.query(
      `
      SELECT
        a1.created_at,
        a1.shortcut,
        a1.firebase_user_uid,
        a1.name,
        a1.description,
        a1.id,
        CASE
          WHEN COUNT(a2.id) > 0
          THEN array_agg(
            jsonb_build_object(
              'id', a2.id,
              'name', a2.name,
              'shortcut', a2.shortcut,
              'created_at', a2.created_at,
              'description', a2.description,
              'firebase_user_uid', a2.firebase_user_uid
            )
          )::jsonb[]
          ELSE ARRAY[]::jsonb[]
        END as related_to_annotations
      FROM
        annotation a1
      LEFT JOIN
        annotation a2 ON a1.id = a2.parent_annotation_id
      WHERE
        a1.id = $1
      GROUP BY
        a1.id, a1.created_at, a1.shortcut, a1.firebase_user_uid, a1.name, a1.description;
    `,
      [newAnnotation.id],
    );

    const formattedResult: CreateAnnotationResponse = {
      createdAt: annotationResult.rows[0].created_at,
      shortcut: annotationResult.rows[0].shortcut,
      firebaseUserUID: annotationResult.rows[0].firebase_user_uid,
      name: annotationResult.rows[0].name,
      description: annotationResult.rows[0].description,
      id: annotationResult.rows[0].id,
      relatedToAnnotations: (
        annotationResult.rows[0].related_to_annotations || []
      ).filter((annotation) => annotation !== null),
    };

    return formattedResult;
  }

  async getAnnotations(): Promise<GetAnnotationsResponse[]> {
    const query = `
        SELECT
            id AS annotation_id,
            created_at,
            shortcut,
            firebase_user_uid,
            name,
            description,
            parent_annotation_id
        FROM
            annotation;
    `;

    const results = await this.conn.query(query);
    const annotations = results.rows;
    const idMap = new Map<string, string>();

    // Build a map of annotation_id to parent_annotation_id
    annotations.forEach((annotation) => {
      idMap.set(annotation.annotation_id, annotation.parent_annotation_id);
    });

    // Function to find the path from an annotation to its topmost parent
    function getPath(currentId: string): string[] {
      if (!currentId || !idMap.has(currentId)) {
        return [];
      }

      const parentId = idMap.get(currentId);
      const pathFromParent = getPath(parentId);

      return [currentId, ...pathFromParent];
    }

    // Transform annotations to the desired format
    const formattedAnnotations = annotations.map((annotation) => {
      const path = getPath(annotation.annotation_id);

      // Use annotation.shortcut for the initial node's shortcut
      const initialShortcut = annotation.shortcut || 'root';

      // Build graphStructure using annotation.shortcut for the initial path
      const graphStructure =
        path.length === 1
          ? `[${initialShortcut}]`
          : `[${initialShortcut}]` +
            path
              .slice(1)
              .map((id) => ` -> [${id}]`)
              .join('');

      // Transform the path IDs to shortcuts for better readability
      const graphStructureWithShortcuts = graphStructure.replace(
        /\[([^\]]+)\]/g,
        (_, id) =>
          `[${
            annotations.find((a) => a.annotation_id === id)?.shortcut ||
            initialShortcut
          }]`,
      );

      // Construct relatedTo array
      const relatedTo = path.slice(1).map((id) => ({
        createdAt: annotations.find((a) => a.annotation_id === id)?.created_at,
        shortcut: annotations.find((a) => a.annotation_id === id)?.shortcut,
        firebaseUserUID: annotations.find((a) => a.annotation_id === id)
          ?.firebase_user_uid,
        name: annotations.find((a) => a.annotation_id === id)?.name,
        description: annotations.find((a) => a.annotation_id === id)
          ?.description,
        id: id,
      }));

      return {
        createdAt: annotation.created_at,
        shortcut: initialShortcut,
        firebaseUserUID: annotation.firebase_user_uid,
        name: annotation.name,
        description: annotation.description,
        id: annotation.annotation_id,
        graphStructure: graphStructureWithShortcuts,
        relatedTo: relatedTo,
      };
    });

    return formattedAnnotations;
  }

  async deleteAnnotation(id: string): Promise<string> {
    try {
      // Check if the annotation exists
      const checkQuery = `
        SELECT 1
        FROM annotation
        WHERE id = $1;
      `;

      const checkResult = await this.conn.query(checkQuery, [id]);

      if (checkResult.rows.length === 0) {
        // Annotation not found
        return 'Annotation not found';
      }

      // Get the parent_annotation_id before deleting the annotation
      const getParentQuery = `
        SELECT parent_annotation_id
        FROM annotation
        WHERE id = $1;
      `;

      const parentResult = await this.conn.query(getParentQuery, [id]);
      const parentId = parentResult.rows[0]?.parent_annotation_id;

      // Now delete the annotation
      const deleteQuery = `
        DELETE FROM annotation
        WHERE id = $1;
      `;

      await this.conn.query(deleteQuery, [id]);

      // Update other annotations if this one was their parent
      if (parentId) {
        const updateChildQuery = `
          UPDATE annotation
          SET parent_annotation_id = NULL
          WHERE parent_annotation_id = $1;
        `;

        await this.conn.query(updateChildQuery, [id]);
      }

      // Annotation deleted successfully
      return 'Annotation deleted successfully';
    } catch (error) {
      // Handle any errors during the deletion process
      console.error('Error deleting annotation:', error.message);
      return 'Error deleting annotation';
    }
  }

  async connectAnnotation(
    connectAnnotationsDto: ConnectAnnotationsDto,
  ): Promise<string> {
    const { annotationParent, annotationChild } = connectAnnotationsDto;
    if (annotationParent === annotationChild) {
      return 'You cannot connect an annotation to itself';
    }

    try {
      // Check if the parent annotation exists
      const checkParentQuery = `
        SELECT 1
        FROM annotation
        WHERE id = $1
      `;

      const checkParentResult = await this.conn.query(checkParentQuery, [
        annotationParent,
      ]);

      if (checkParentResult.rows.length === 0) {
        // Parent annotation not found
        return 'Parent annotation not found';
      }

      // Check if the child annotation exists
      const checkChildQuery = `
        SELECT 1
        FROM annotation
        WHERE id = $1
      `;

      const checkChildResult = await this.conn.query(checkChildQuery, [
        annotationChild,
      ]);

      if (checkChildResult.rows.length === 0) {
        // Child annotation not found
        return 'Child annotation not found';
      }

      // Update the child annotation's parent_annotation_id
      const updateParentQuery = `
        UPDATE annotation
        SET parent_annotation_id = $1
        WHERE id = $2
      `;

      await this.conn.query(updateParentQuery, [
        annotationParent,
        annotationChild,
      ]);

      return 'Annotation connected successfully';
    } catch (error) {
      // Handle any errors during the process
      console.error('Error connecting annotations:', error.message);
      return 'Error connecting annotations';
    }
  }

  async annotateColumn(
    annotateColumnDto: AnnotateColumnDto,
  ): Promise<boolean[]> {
    const { firebaseDatasetID, columns } = annotateColumnDto;
    const results: boolean[] = [];

    for (const { columnName, selectedAnnotationId } of columns) {
      const existingIsAnnotatedRelationship = await this.conn.query({
        text: `
          SELECT 1
          FROM dataset
          JOIN dataset_column ON dataset.firebase_dataset_id = $1
          JOIN column_annotation ON dataset_column.id = column_annotation.column_id
          JOIN annotation ON annotation.id = $2
          WHERE dataset_column.column_name = $3
            AND column_annotation.annotation_id = annotation.id
        `,
        values: [firebaseDatasetID, selectedAnnotationId, columnName],
      });

      if (existingIsAnnotatedRelationship.rows.length === 0) {
        // Create the 'ANNOTATED_WITH' relationship
        const createResult = await this.conn.query({
          text: `
            INSERT INTO column_annotation (column_id, annotation_id)
            SELECT dataset_column.id, annotation.id
            FROM dataset
            JOIN dataset_column ON dataset.firebase_dataset_id = $1 AND dataset_column.column_name = $2
            JOIN annotation ON annotation.id = $3
            RETURNING column_annotation.*;
          `,
          values: [firebaseDatasetID, columnName, selectedAnnotationId],
        });

        results.push(createResult.rows.length > 0);
      } else {
        results.push(false);
      }
    }

    return results;
  }

  async getColumnsAnnotations(
    firebaseDatasetId: string,
  ): Promise<GetColumnsAnnotationsResponse[]> {
    // Step 1: Get dataset_id using firebaseDatasetId
    const datasetIdResult = await this.conn.query({
      text: 'SELECT id FROM dataset WHERE firebase_dataset_id = $1',
      values: [firebaseDatasetId],
    });

    if (datasetIdResult.rows.length === 0) {
      // Handle the case where no dataset with the given firebaseDatasetId is found
      return [];
    }

    const datasetId = datasetIdResult.rows[0].id;

    // Step 2: Execute the main query to get columns and annotations
    const query = `
      SELECT
        dataset_column.id,
        dataset_column.column_name,
        dataset_column.column_description,
        COALESCE(
          (
            SELECT
              jsonb_agg(
                jsonb_build_object(
                  'id', annotation.id,
                  'name', annotation.name,
                  'description', annotation.description,
                  'createdAt', annotation.created_at,
                  'firebaseUserUID', annotation.firebase_user_uid,
                  'shortcut', annotation.shortcut
                )
              )
            FROM column_annotation
            LEFT JOIN annotation ON column_annotation.annotation_id = annotation.id
            WHERE column_annotation.column_id = dataset_column.id
          ), '[]'::jsonb
        ) as annotations
      FROM dataset_column
      WHERE dataset_column.dataset_id = $1
      GROUP BY dataset_column.id, dataset_column.column_name, dataset_column.column_description;
    `;

    const result = await this.conn.query({
      text: query,
      values: [datasetId],
    });

    const columnsWithAnnotations = result.rows.map((row) => {
      const datasetColumn = row || {}; // Default to an empty object if undefined
      const { column_name, column_description } = datasetColumn;
      const annotations = row.annotations || []; // Use an empty array if annotations is null

      return {
        column: {
          columnName: column_name,
          columnDescription: column_description,
        },
        annotations,
      };
    });

    return columnsWithAnnotations;
  }

  async getAnnotationsSuggestions(
    getAnnotationsSuggestionsDTO: GetAnnotationsSuggestionsDTO,
  ): Promise<GetAnnotationsSuggestionsResponse[]> {
    const { columnsForAnnotationsSuggestionsArray, id } =
      getAnnotationsSuggestionsDTO;

    const columnsArray: GetAnnotationsSuggestionsResponse[] = [];

    for (const columnName of columnsForAnnotationsSuggestionsArray) {
      const query = `
        SELECT
          LOWER(dataset_column.column_name) AS columnName,
          jsonb_build_object(
            'id', annotation.id,
            'name', annotation.name,
            'description', annotation.description,
            'createdAt', annotation.created_at,
            'firebaseUserUID', annotation.firebase_user_uid,
            'shortcut', annotation.shortcut,
            'count', count(*) -- Count the occurrences
          ) AS annotation
        FROM dataset
        LEFT JOIN dataset_column ON dataset.id = dataset_column.dataset_id
        LEFT JOIN column_annotation ON dataset_column.id = column_annotation.column_id
        LEFT JOIN annotation ON column_annotation.annotation_id = annotation.id
        WHERE dataset.firebase_dataset_id <> $1 AND LOWER(dataset_column.column_name) ILIKE LOWER($2)
        GROUP BY LOWER(dataset_column.column_name), annotation.id
        ORDER BY count(*) DESC; -- Order by count from highest to lowest
      `;

      const result = await this.conn.query({
        text: query,
        values: [id, columnName],
      });

      const columnsMap = new Map();
      result.rows.forEach((row) => {
        const columnNameLower = row.columnname.toLowerCase();
        if (!columnsMap.has(columnNameLower)) {
          columnsMap.set(columnNameLower, {
            columnName: row.columnname,
            annotations: [],
          });
        }

        // Add the individual annotation to the annotations array
        const columnEntry = columnsMap.get(columnNameLower);
        columnEntry.annotations.push(row.annotation);
      });

      // Convert the map values to an array of columns
      const columns = Array.from(columnsMap.values());
      columnsArray.push(...columns);
    }

    return columnsArray;
  }

  async getExport(id: string): Promise<GetExportResponse> {
    const getAnnotations = async (): Promise<any[]> => {
      const query = `
            SELECT
                id AS annotation_id,
                created_at,
                shortcut,
                firebase_user_uid,
                name,
                description,
                parent_annotation_id
            FROM
                annotation;
            `;
      const results = await this.conn.query(query);
      return results.rows;
    };

    const constructFullPath = (currentId: string, annotations: any[]): any => {
      const annotation = annotations.find((a) => a.annotation_id === currentId);
      if (!annotation) {
        return null;
      }

      const fullPathAnnotation = {
        shortcut: annotation.shortcut,
        name: annotation.name,
        description: annotation.description,
        id: annotation.annotation_id,
        related_to: [],
      };

      if (annotation.parent_annotation_id) {
        const parentFullPath = constructFullPath(
          annotation.parent_annotation_id,
          annotations,
        );
        if (parentFullPath) {
          fullPathAnnotation.related_to.push(parentFullPath);
        }
      }

      return fullPathAnnotation;
    };

    const annotations = await getAnnotations();

    const query = `
        SELECT
            dataset.*,
            dataset_column.id AS "columnId",
            dataset_column.column_name AS "columnName",
            dataset_column.column_description AS "columnDescription",
            annotation.id AS "annotationId",
            annotation.shortcut AS "shortcut",
            annotation.name AS "name",
            annotation.description AS "description",
            related_annotation.id AS "relatedToId",
            related_annotation.shortcut AS "relatedToShortcut",
            related_annotation.name AS "relatedToName",
            related_annotation.description AS "relatedToDescription",
            related_annotation.parent_annotation_id AS "relatedToParentId"
        FROM dataset
        LEFT JOIN dataset_column ON dataset.id = dataset_column.dataset_id
        LEFT JOIN column_annotation ON dataset_column.id = column_annotation.column_id
        LEFT JOIN annotation ON column_annotation.annotation_id = annotation.id
        LEFT JOIN annotation AS related_annotation ON annotation.parent_annotation_id = related_annotation.id
        WHERE dataset.firebase_dataset_id = $1
        ORDER BY LOWER(dataset_column.column_name), LOWER(annotation.name);
    `;

    const result = await this.conn.query({
      text: query,
      values: [id],
    });

    const columnsMap = new Map();

    result.rows.forEach((row) => {
      const columnKey = row.columnName.toLowerCase();

      if (!columnsMap.has(columnKey)) {
        columnsMap.set(columnKey, {
          columnDescription: row.columnDescription,
          columnName: row.columnName,
          annotations: [],
        });
      }

      const annotation = {
        shortcut: row.shortcut,
        name: row.name,
        description: row.description,
        id: row.annotationId,
        related_to: [],
      };

      if (row.relatedToId) {
        const relatedToFullPath = constructFullPath(
          row.relatedToId,
          annotations,
        );
        if (relatedToFullPath) {
          annotation.related_to.push(relatedToFullPath);
        }
      }

      // Push annotation only if it's not an empty object
      if (
        Object.values(annotation).some(
          (value) =>
            value !== null &&
            value !== '' &&
            (!Array.isArray(value) || value.length !== 0),
        )
      ) {
        columnsMap.get(columnKey).annotations.push(annotation);
      }
    });

    // Extract dataset information from the query result
    const datasetInfo =
      result.rows.length > 0
        ? {
            datasetDescription: result.rows[0].dataset_description,
            firebaseUserUID: result.rows[0].firebase_user_uid,
            datasetName: result.rows[0].dataset_name,
            firebaseDatasetID: result.rows[0].firebase_dataset_id,
          }
        : null;

    return {
      dataset: datasetInfo,
      columns: Array.from(columnsMap.values()),
    };
  }

  async postImport(
    csvFile: UploadedFile,
    jsonFile: UploadedFile,
    authorizationToken: string,
  ): Promise<any> {
    const app = this.firebaseService.getAdmin();
    const storage = app.storage();
    const db = app.firestore();
    const datasetsCollection = db.collection('datasets');
    const bucket = storage.bucket('diploma-thesis-project-c46d9.appspot.com'); // Replace with your actual bucket name

    // Read the content of the JSON file
    const jsonContent: string = jsonFile.buffer.toString('utf8');
    // Parse the JSON content
    const parsedJsonData: any = JSON.parse(jsonContent);

    let datasetSize = null;
    const result = await getAuth().verifyIdToken(authorizationToken);
    const userEmail = result.email;
    const userUID = result.uid;
    let fileName = csvFile.originalname;
    const uniqueFileName = `${uuidv4()}_${fileName}`;
    const file = new Uint8Array(csvFile.buffer);
    const fileRef = bucket.file(`csvFiles/${uniqueFileName}`);
    await fileRef.save(file);
    const [downloadUrl] = await fileRef.getSignedUrl({
      action: 'read',
      expires: '01-01-2100', // Expiration date for the URL
    });

    if (fileName) {
      fileName = fileName.replace('.csv', '');
    }

    const size = csvFile.size;
    if (size <= SMALL_FILE_SIZE_THRESHOLD) {
      datasetSize = 'small';
    } else if (size <= MEDIUM_FILE_SIZE_THRESHOLD) {
      datasetSize = 'medium';
    } else {
      datasetSize = 'big';
    }

    const now = new Date();

    const options: Intl.DateTimeFormatOptions = {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    };

    const formatter = new Intl.DateTimeFormat('en-US', options);
    const timestamp = formatter.format(now);

    if (downloadUrl) {
      try {
        const data = {
          datasetName: fileName,
          authorName: userEmail,
          authorUID: userUID,
          publishDate: timestamp,
          size: datasetSize,
          csvFileUrl: downloadUrl.toString(),
        };

        const docRef = await datasetsCollection.add(data);
        const datasetId = docRef.id;
        // createDatset
        await this.conn.query(
          'INSERT INTO dataset (firebase_user_uid, firebase_dataset_id, dataset_name, dataset_description) VALUES ($1, $2, $3, $4) RETURNING id, firebase_user_uid, firebase_dataset_id, dataset_name, dataset_description;',
          [
            userUID,
            datasetId,
            parsedJsonData.dataset.datasetName,
            parsedJsonData.dataset.datasetDescription,
          ],
        );

        // put the columns and add the columns descriptions
        // Iterate over each column in the array

        //
        await this.conn.query('BEGIN');

        try {
          for (const {
            columnName,
            columnDescription,
          } of parsedJsonData.columns) {
            // Try to update the column, if it exists
            const updateQuery = `
          WITH existing_column AS (
            SELECT id, column_description
            FROM dataset_column
            WHERE dataset_id = (
              SELECT id
              FROM dataset
              WHERE firebase_dataset_id = $1
            ) AND column_name = $2
            FOR UPDATE
          )
          UPDATE dataset_column
          SET column_description = $3
          FROM existing_column
          WHERE dataset_column.id = existing_column.id
          RETURNING dataset_column.column_name, dataset_column.column_description;
        `;

            const updateResult = await this.conn.query(updateQuery, [
              datasetId,
              columnName,
              columnDescription,
            ]);

            if (updateResult.rows.length > 0) {
            } else {
              // If no rows were updated, insert a new column
              const insertQuery = `
            INSERT INTO dataset_column (dataset_id, column_name, column_description)
            VALUES (
              (SELECT id FROM dataset WHERE firebase_dataset_id = $1),
              $2,
              $3
            )
            RETURNING dataset_column.column_name, dataset_column.column_description;
          `;

              await this.conn.query(insertQuery, [
                datasetId,
                columnName,
                columnDescription,
              ]);
            }
          }

          // Commit the transaction
          await this.conn.query('COMMIT');
        } catch (error) {
          // Rollback the transaction in case of an error
          await this.conn.query('ROLLBACK');
          console.error(error);
          return null;
        }

        // create annotations and related annotations and map them to the columns
        // first create all the annotations
        async function createAnnotationsAndRelated(
          annotations: any[],
          userUID: string,
        ): Promise<void> {
          for (const annotation of annotations) {
            const { id, name, description, shortcut } = annotation;

            // Check if the annotation already exists
            const query = 'SELECT id FROM annotation WHERE id = $1';
            const result = await this.conn.query(query, [id]);
            const existingAnnotation = result.rowCount > 0;
            if (!existingAnnotation) {
              // Annotation doesn't exist, create it
              const insertQuery = `
                    INSERT INTO annotation (id, name, description, shortcut, firebase_user_uid, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6);
                  `;
              const createdAt = new Date();
              const values = [
                id,
                name,
                description,
                shortcut,
                userUID,
                createdAt,
              ];
              await this.conn.query(insertQuery, values);
            }

            if (annotation.related_to && annotation.related_to.length > 0) {
              await createAnnotationsAndRelated.call(
                this,
                annotation.related_to,
                userUID,
              );
            }
          }
        }

        for (const { annotations } of parsedJsonData.columns) {
          await createAnnotationsAndRelated.call(this, annotations, userUID);
        }

        // Match annotations with their corresponding columns
        for (const { columnName, annotations } of parsedJsonData.columns) {
          // Match the column
          const columnQuery = `
              SELECT id FROM dataset_column
              WHERE dataset_id = (
                SELECT id FROM dataset
                WHERE firebase_dataset_id = $1
              ) AND column_name = $2;
          `;
          const columnValues = [datasetId, columnName];
          const columnResult = await this.conn.query(columnQuery, columnValues);

          if (columnResult.rows.length > 0) {
            const columnId = columnResult.rows[0].id;

            // Iterate through annotations
            for (const { id } of annotations) {
              // Check if the annotation is already associated with the column
              const annotationColumnQuery = `
                  SELECT * FROM column_annotation
                  WHERE column_id = $1 AND annotation_id = $2;
              `;
              const annotationColumnValues = [columnId, id];
              const annotationColumnResult = await this.conn.query(
                annotationColumnQuery,
                annotationColumnValues,
              );

              if (annotationColumnResult.rows.length === 0) {
                // If not associated, insert the association
                const insertAnnotationColumnQuery = `
                    INSERT INTO column_annotation (column_id, annotation_id)
                    VALUES ($1, $2);
                `;
                const insertAnnotationColumnValues = [columnId, id];
                await this.conn.query(
                  insertAnnotationColumnQuery,
                  insertAnnotationColumnValues,
                );
              }
            }
          }
        }

        // Define a recursive function to create relationships between annotations and their related annotations
        async function createRelationships(
          annotationId: string,
          relatedAnnotations: any[],
        ) {
          for (const related of relatedAnnotations) {
            const { id: relatedId, related_to: nestedRelated } = related;

            try {
              // Check if the relationship already exists
              const existingRelationshipQuery = `
        SELECT 1 FROM annotation
        WHERE id = $1 AND parent_annotation_id = $2
      `;
              const { rowCount } = await this.conn.query(
                existingRelationshipQuery,
                [annotationId, relatedId],
              );

              if (rowCount === 0) {
                // Update the parent_annotation_id for the annotation
                await this.conn.query(
                  'UPDATE annotation SET parent_annotation_id = $1 WHERE id = $2',
                  [relatedId, annotationId],
                );
              }

              // Recursively create relationships for nested related annotations
              if (nestedRelated && nestedRelated.length > 0) {
                await createRelationships.call(this, relatedId, nestedRelated);
              }
            } catch (error) {
              console.error(
                `Error creating relationship for annotation ${relatedId}:`,
                error,
              );
            }
          }
        }

        // Iterate through each column and its annotations
        for (const { annotations } of parsedJsonData.columns) {
          for (const annotation of annotations) {
            const { id: annotationId, related_to } = annotation;

            // Create relationships for related annotations
            if (related_to && related_to.length > 0) {
              await createRelationships.call(this, annotationId, related_to);
            }
          }
        }
        return true;
      } catch (error) {
        console.error('Error uploading file:', error.message);
        return false;
      }
    }
  }
}
