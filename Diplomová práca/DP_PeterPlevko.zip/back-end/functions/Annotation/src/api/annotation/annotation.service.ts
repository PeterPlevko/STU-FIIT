// annotation.service.ts
import { Injectable } from '@nestjs/common';
import { CreateAnnotationDto } from './dto-and-response/create-annotation.dto';
import { CreateAnnotationResponse } from './dto-and-response/create-annotation-response';
import { AnnotateColumnDto } from './dto-and-response/annotate-column-dto';
import { ConnectAnnotationsDto } from './dto-and-response/connect-annotations-dto';
import { GetColumnsAnnotationsResponse } from './dto-and-response/get-columns-annotations-response';
import { GetExportResponse } from './dto-and-response/get-export-response';
import { GetAnnotationsResponse } from './dto-and-response/get-annotations-response';
import { GetAnnotationsSuggestionsDTO } from './dto-and-response/getAnnotationsSuggestions-dto';
import { GetAnnotationsSuggestionsResponse } from './dto-and-response/getAnnotationsSuggestions-response';

interface UploadedFile {
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  buffer: Buffer;
  size: number;
}

@Injectable()
export abstract class AnnotationService {
  abstract createAnnotation(
    createAnnotationDto: CreateAnnotationDto,
  ): Promise<CreateAnnotationResponse>;

  abstract getAnnotations(): Promise<GetAnnotationsResponse[]>;
  abstract annotateColumn(
    annotateColumnDto: AnnotateColumnDto,
  ): Promise<boolean[]>;

  abstract getExport(id: string): Promise<GetExportResponse>;

  abstract deleteAnnotation(id: string): Promise<string>;

  abstract connectAnnotation(
    connectAnnotationsDto: ConnectAnnotationsDto,
  ): Promise<string>;

  abstract getColumnsAnnotations(
    datasetId: string,
  ): Promise<GetColumnsAnnotationsResponse[]>;

  abstract getAnnotationsSuggestions(
    getAnnotationsSuggestionsDTO: GetAnnotationsSuggestionsDTO,
  ): Promise<GetAnnotationsSuggestionsResponse[]>;

  abstract postImport(
    csvFile: UploadedFile,
    jsonFile: UploadedFile,
    authorizationToken: string,
  ): Promise<boolean>;
}
